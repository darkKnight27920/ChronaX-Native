package com.chronax.clock

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone

/**
 * Android schedule projection prototype. The current Dart store is still
 * SharedPreferences and is not yet wired to this snapshot. The intended final
 * design is Flutter/SQLite as canonical alarm source; this compact snapshot
 * will then be rebuilt from that source after boot/time/permission changes.
 */
object ChronaAlarmScheduler {
    private const val PREFS = "chrona_alarm_projection"
    private const val KEY = "enabled_alarms_v1"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun manager(context: Context) = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun alarmIntent(context: Context, id: String): PendingIntent {
        val intent = Intent(context, ChronaAlarmReceiver::class.java)
            .setAction("com.chronax.clock.ALARM_FIRE")
            .setData(Uri.parse("chronax://alarm/${Uri.encode(id)}"))
            .putExtra("id", id)
        return PendingIntent.getBroadcast(
            context, stableRequestCode(id), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(
            context, 71010000, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun stableRequestCode(id: String): Int {
        // Stable across process restarts. Intent data URI also makes PendingIntent identity unique.
        var hash = 0x811c9dc5.toInt()
        id.toByteArray(Charsets.UTF_8).forEach { hash = (hash xor (it.toInt() and 0xff)) * 0x01000193 }
        return hash and 0x7fffffff
    }

    fun exactAlarmAllowed(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S || manager(context).canScheduleExactAlarms()

    fun schedule(
        context: Context,
        id: String,
        title: String,
        triggerAtEpochMs: Long,
        repeatMask: Int,
        localHour: Int,
        localMinute: Int,
        timeZoneId: String
    ): Map<String, Any> {
        if (id.isBlank() || triggerAtEpochMs <= System.currentTimeMillis() ||
            localHour !in 0..23 || localMinute !in 0..59 || repeatMask !in 0..127) {
            return mapOf("scheduled" to false, "status" to "invalid-alarm-data")
        }
        if (!exactAlarmAllowed(context)) {
            return mapOf("scheduled" to false, "status" to "exact-alarm-access-required")
        }
        val record = JSONObject()
            .put("id", id)
            .put("title", title)
            .put("triggerAtEpochMs", triggerAtEpochMs)
            .put("repeatMask", repeatMask)
            .put("localHour", localHour)
            .put("localMinute", localMinute)
            .put("timeZoneId", timeZoneId)
            .put("enabled", true)
        upsertProjection(context, record)
        register(context, record)
        return mapOf("scheduled" to true, "status" to "exact-alarm-registered")
    }

    private fun register(context: Context, record: JSONObject) {
        val id = record.optString("id")
        val trigger = record.optLong("triggerAtEpochMs")
        if (id.isBlank() || trigger <= System.currentTimeMillis()) return
        val operation = alarmIntent(context, id)
        val info = AlarmManager.AlarmClockInfo(trigger, showIntent(context))
        manager(context).setAlarmClock(info, operation)
    }

    fun cancel(context: Context, id: String) {
        if (id.isBlank()) return
        manager(context).cancel(alarmIntent(context, id))
        val old = projection(context)
        val next = JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optString("id") != id) next.put(item)
        }
        prefs(context).edit().putString(KEY, next.toString()).apply()
    }

    fun handleFired(context: Context, id: String): JSONObject? {
        val old = projection(context)
        var fired: JSONObject? = null
        val next = JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optString("id") == id) fired = item else next.put(item)
        }
        val record = fired ?: return null
        val repeatMask = record.optInt("repeatMask")
        if (repeatMask == 0) {
            prefs(context).edit().putString(KEY, next.toString()).apply()
            return record
        }
        val nextEpoch = nextWeeklyOccurrence(
            System.currentTimeMillis(), repeatMask,
            record.optInt("localHour"), record.optInt("localMinute"),
            record.optString("timeZoneId", TimeZone.getDefault().id)
        )
        if (nextEpoch != null) {
            record.put("triggerAtEpochMs", nextEpoch)
            next.put(record)
            prefs(context).edit().putString(KEY, next.toString()).apply()
            register(context, record)
        } else {
            // Invalid timezone/recurrence must not leave a silently stale alarm registered.
            prefs(context).edit().putString(KEY, next.toString()).apply()
        }
        return record
    }

    fun restore(context: Context) {
        if (!exactAlarmAllowed(context)) return
        val all = projection(context)
        val now = System.currentTimeMillis()
        for (i in 0 until all.length()) {
            val record = all.optJSONObject(i) ?: continue
            if (!record.optBoolean("enabled", true)) continue
            val id = record.optString("id")
            var trigger = record.optLong("triggerAtEpochMs")
            if (id.isBlank()) continue
            if (record.optInt("repeatMask") != 0) {
                // Weekly alarms are wall-clock rules; recompute after timezone/time changes.
                val next = nextWeeklyOccurrence(
                    now, record.optInt("repeatMask"), record.optInt("localHour"),
                    record.optInt("localMinute"), record.optString("timeZoneId", TimeZone.getDefault().id)
                ) ?: continue
                trigger = next
                record.put("triggerAtEpochMs", trigger)
            }
            if (trigger > now) register(context, record)
        }
        prefs(context).edit().putString(KEY, all.toString()).apply()
    }

    private fun nextWeeklyOccurrence(
        afterEpochMs: Long, repeatMask: Int, hour: Int, minute: Int, zoneId: String
    ): Long? {
        if (repeatMask !in 1..127 || hour !in 0..23 || minute !in 0..59) return null
        if (!TimeZone.getAvailableIDs().contains(zoneId)) return null
        val zone = TimeZone.getTimeZone(zoneId)
        val calendar = Calendar.getInstance(zone).apply {
            timeInMillis = afterEpochMs
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        repeat(8) {
            val dayBit = 1 shl (calendar.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY)
            if (calendar.timeInMillis > afterEpochMs && (repeatMask and dayBit) != 0) {
                return calendar.timeInMillis
            }
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }
        return null
    }

    private fun projection(context: Context): JSONArray =
        runCatching { JSONArray(prefs(context).getString(KEY, "[]")) }.getOrElse { JSONArray() }

    private fun upsertProjection(context: Context, record: JSONObject) {
        val old = projection(context)
        val next = JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optString("id") != record.optString("id")) next.put(item)
        }
        next.put(record)
        prefs(context).edit().putString(KEY, next.toString()).apply()
    }
}
