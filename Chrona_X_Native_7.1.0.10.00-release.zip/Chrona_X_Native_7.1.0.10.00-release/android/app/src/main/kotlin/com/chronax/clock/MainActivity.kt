package com.chronax.clock

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "com.chronax.clock/platform"
    private var platformChannel: MethodChannel? = null
    private val notificationRequestCode = 7101

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        platformChannel = MethodChannel(engine.dartExecutor.binaryMessenger, channelName)
        platformChannel?.setMethodCallHandler { call, result ->
            when (call.method) {
                "capabilities" -> result.success(capabilities())
                "requestExactAlarmAccess" -> {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || ChronaAlarmScheduler.exactAlarmAllowed(this)) {
                        result.success(mapOf("status" to "already-granted"))
                    } else {
                        runCatching {
                            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                        }.onSuccess { result.success(mapOf("status" to "settings-opened")) }
                            .onFailure { result.success(mapOf("status" to "settings-unavailable", "detail" to it.javaClass.simpleName)) }
                    }
                }
                "requestNotificationPermission" -> {
                    if (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                        result.success(mapOf("status" to "already-granted"))
                    } else {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequestCode)
                        result.success(mapOf("status" to "request-launched"))
                    }
                }
                "openNotificationSettings" -> openSystemSettings(
                    result,
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                )
                "openAppSettings" -> openSystemSettings(
                    result,
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
                "scheduleAlarm" -> {
                    val id = call.argument<String>("id")
                    val title = call.argument<String>("title") ?: "Chrona X alarm"
                    val at = call.argument<Number>("triggerAtEpochMs")?.toLong()
                    val mask = call.argument<Int>("repeatMask") ?: 0
                    val hour = call.argument<Int>("localHour") ?: -1
                    val minute = call.argument<Int>("localMinute") ?: -1
                    val zone = call.argument<String>("timeZoneId") ?: java.util.TimeZone.getDefault().id
                    if (id == null || at == null) {
                        result.error("INVALID_ARGUMENT", "id and triggerAtEpochMs are required", null)
                    } else {
                        result.success(ChronaAlarmScheduler.schedule(this, id, title, at, mask, hour, minute, zone))
                    }
                }
                "cancelAlarm" -> {
                    val id = call.argument<String>("id")
                    if (id == null) result.error("INVALID_ARGUMENT", "id required", null)
                    else { ChronaAlarmScheduler.cancel(this, id); result.success(null) }
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        platformChannel?.invokeMethod("capabilitiesChanged", capabilities())
    }

    private fun openSystemSettings(result: MethodChannel.Result, intent: Intent) {
        runCatching { startActivity(intent) }
            .onSuccess { result.success(mapOf("status" to "settings-opened")) }
            .onFailure { result.success(mapOf("status" to "settings-unavailable", "detail" to it.javaClass.simpleName)) }
    }

    private fun capabilities(): Map<String, Any> {
        val exact = ChronaAlarmScheduler.exactAlarmAllowed(this)
        val notificationsRuntime = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val notificationsEnabled = NotificationManagerCompat.from(this).areNotificationsEnabled()
        return mapOf(
            "bridge" to "available",
            "androidApi" to Build.VERSION.SDK_INT,
            "exactAlarmAccess" to exact,
            "notificationsRuntimePermission" to notificationsRuntime,
            "notificationsEnabled" to notificationsEnabled,
            "alarmScheduling" to if (exact) "exact-capable" else "permission-required"
        )
    }
}
