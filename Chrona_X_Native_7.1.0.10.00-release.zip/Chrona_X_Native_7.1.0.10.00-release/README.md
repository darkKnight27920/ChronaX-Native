# Chrona X Native Android

**Product version:** `7.1.0.10.00-release` (locked)  
**Repository:** `darkKnight27920/ChronaX-Native`  
**Architecture:** Flutter/Dart + Rust + Kotlin Android; no WebView shell.

Chrona X is a product IP with a flagship Clock app and a future shared-core ecosystem. The Web/PWA remains a separate product delivery. Historical HTML is retained only as reference/requirements evidence.

## Read first

1. [`docs/VERSION_AUTHORITY.md`](docs/VERSION_AUTHORITY.md)
2. [`docs/FEATURE_GAPS_AND_FIX_PLAN.md`](docs/FEATURE_GAPS_AND_FIX_PLAN.md)
3. [`docs/ARCHITECTURE_AND_STACK.md`](docs/ARCHITECTURE_AND_STACK.md)
4. [`docs/IP_ECOSYSTEM_AND_NETWORK_IDENTITY.md`](docs/IP_ECOSYSTEM_AND_NETWORK_IDENTITY.md)
5. [`docs/APK_BUILD_AND_RELEASE_GATES.md`](docs/APK_BUILD_AND_RELEASE_GATES.md)
6. [`docs/DEVICE_PROFILE_AND_TEST_PLAN.md`](docs/DEVICE_PROFILE_AND_TEST_PLAN.md)
7. [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md)

## Ownership

- Flutter: native UI, interaction, accessibility and app navigation.
- Rust: deterministic platform-independent time/date/domain calculations.
- Kotlin: Android alarms, permissions, notifications, lifecycle and system integrations.
- SQLite/Drift: planned canonical local product data store. Android's alarm snapshot is a derived registration projection, not a second product database.
- WorkManager: future deferrable maintenance only, never a substitute for exact clock alarms.

## Important

The repository and project package are an engineering foundation. Full feature parity, ringtone/audio-focus, complete alarm UX, database migration, generated Rust bridge, APK/AAB signing and physical-device validation are not complete. Do not treat the project as release-ready until every release gate has evidence.

The public repository contains no signing credentials. Never commit keystores, API tokens, passwords or personal data.
