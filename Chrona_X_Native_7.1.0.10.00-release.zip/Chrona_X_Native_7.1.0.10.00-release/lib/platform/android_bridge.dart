import 'package:flutter/services.dart';

/// Thin adapter to the Android platform owner. Permission results are queried
/// from Android, never inferred from a local toggle.
class AndroidBridge {
  AndroidBridge({this.onCapabilitiesChanged}) {
    _channel.setMethodCallHandler(_handleNativeCall);
  }

  final void Function(Map<String, dynamic>)? onCapabilitiesChanged;
  static const _channel = MethodChannel('com.chronax.clock/platform');

  Future<void> _handleNativeCall(MethodCall call) async {
    if (call.method == 'capabilitiesChanged') {
      final raw = call.arguments;
      if (raw is Map) onCapabilitiesChanged?.call(Map<String, dynamic>.from(raw));
    }
  }

  Future<Map<String, dynamic>> capabilities() async =>
      Map<String, dynamic>.from(await _channel.invokeMethod<Map>('capabilities') ?? {});

  Future<Map<String, dynamic>> scheduleAlarm(Map<String, dynamic> alarm) async =>
      Map<String, dynamic>.from(await _channel.invokeMethod<Map>('scheduleAlarm', alarm) ?? {});

  Future<void> cancelAlarm(String id) => _channel.invokeMethod('cancelAlarm', {'id': id});

  Future<String> requestExactAlarmAccess() async {
    final result = await _channel.invokeMethod<Map>('requestExactAlarmAccess') ?? {};
    return result['status']?.toString() ?? 'unknown';
  }

  Future<String> requestNotificationPermission() async {
    final result = await _channel.invokeMethod<Map>('requestNotificationPermission') ?? {};
    return result['status']?.toString() ?? 'unknown';
  }

  Future<String> openNotificationSettings() async {
    final result = await _channel.invokeMethod<Map>('openNotificationSettings') ?? {};
    return result['status']?.toString() ?? 'unknown';
  }

  Future<String> openAppSettings() async {
    final result = await _channel.invokeMethod<Map>('openAppSettings') ?? {};
    return result['status']?.toString() ?? 'unknown';
  }
}
