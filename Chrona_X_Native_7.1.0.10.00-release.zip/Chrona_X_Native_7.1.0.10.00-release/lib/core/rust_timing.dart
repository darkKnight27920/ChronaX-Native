import 'dart:ffi';
import 'dart:math' as math;

/// Rust-backed deterministic primitives. Android scheduling remains Kotlin-owned.
/// If the native library is unavailable (for example, in a Dart test), callers
/// can use the safe Dart fallback instead of crashing during application startup.
class RustTimingCore {
  RustTimingCore._(DynamicLibrary library)
      : _elapsed = library.lookupFunction<_I64x2, _I64x2>('cx_elapsed_ms'),
        _remaining = library.lookupFunction<_I64x2, _I64x2>('cx_remaining_ms'),
        _signedDifference = library.lookupFunction<_I64x2, _I64x2>('cx_signed_difference_ms'),
        _clamp = library.lookupFunction<_I64x3, _I64x3>('cx_clamp_duration_ms'),
        _dateDistance = library.lookupFunction<_DateDistanceNative, _DateDistanceDart>(
          'cx_date_distance_days',
        );

  final int Function(int, int) _elapsed;
  final int Function(int, int) _remaining;
  final int Function(int, int) _signedDifference;
  final int Function(int, int, int) _clamp;
  final int Function(int, int, int, int, int, int) _dateDistance;

  static RustTimingCore openAndroid() =>
      RustTimingCore._(DynamicLibrary.open('libchrona_core.so'));

  static RustTimingCore? tryOpenAndroid() {
    try {
      return openAndroid();
    } on Object {
      return null;
    }
  }

  int elapsedMilliseconds(int startEpochMs, int nowEpochMs) =>
      _elapsed(startEpochMs, nowEpochMs);

  int remainingMilliseconds(int targetEpochMs, int nowEpochMs) =>
      _remaining(targetEpochMs, nowEpochMs);

  int signedDifferenceMilliseconds(int startEpochMs, int endEpochMs) =>
      _signedDifference(startEpochMs, endEpochMs);

  int clampDurationMilliseconds(int value, int minimum, int maximum) =>
      _clamp(value, minimum, maximum);

  int? dateDistanceDays({
    required int startYear,
    required int startMonth,
    required int startDay,
    required int endYear,
    required int endMonth,
    required int endDay,
  }) {
    final result = _dateDistance(
      startYear, startMonth, startDay, endYear, endMonth, endDay,
    );
    return result == -9223372036854775808 ? null : result;
  }
}

/// Domain-facing facade with a deterministic Dart fallback for tests/platforms
/// where the native library has not been packaged yet.
class ChronaTimingEngine {
  const ChronaTimingEngine({this.nativeCore});

  final RustTimingCore? nativeCore;

  int elapsedMilliseconds(int start, int now) =>
      nativeCore?.elapsedMilliseconds(start, now) ?? math.max(0, now - start).toInt();

  int remainingMilliseconds(int target, int now) =>
      nativeCore?.remainingMilliseconds(target, now) ?? math.max(0, target - now).toInt();

  int signedDifferenceMilliseconds(int start, int end) =>
      nativeCore?.signedDifferenceMilliseconds(start, end) ?? end - start;
}

typedef _I64x2 = Int64 Function(Int64, Int64);
typedef _I64x3 = Int64 Function(Int64, Int64, Int64);
typedef _DateDistanceNative = Int64 Function(
  Int32, Uint32, Uint32, Int32, Uint32, Uint32,
);
typedef _DateDistanceDart = int Function(int, int, int, int, int, int);
