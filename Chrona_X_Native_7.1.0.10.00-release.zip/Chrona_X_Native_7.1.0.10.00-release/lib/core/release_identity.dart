/// Single authority for the public Chrona X release identity.
abstract final class ReleaseIdentity {
  static const product = 'Chrona X';
  static const versionName = '7.1.0.10.00-release';
  static const packageVersion = '7.1.0+71010000';
}
