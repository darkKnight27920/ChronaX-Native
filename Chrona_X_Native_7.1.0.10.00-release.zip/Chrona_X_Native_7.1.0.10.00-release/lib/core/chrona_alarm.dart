/// Domain representation of a user-authored alarm.
/// Sunday is bit 0, Monday bit 1, ... Saturday bit 6 in [repeatMask].
class ChronaAlarm {
  const ChronaAlarm({
    required this.id,
    required this.title,
    required this.hour,
    required this.minute,
    required this.repeatMask,
    required this.timeZoneId,
    required this.enabled,
    this.snoozeMinutes = 10,
    this.ringtoneUri,
  });

  final String id;
  final String title;
  final int hour;
  final int minute;
  final int repeatMask;
  final String timeZoneId;
  final bool enabled;
  final int snoozeMinutes;
  final String? ringtoneUri;

  bool get isValid => id.trim().isNotEmpty &&
      hour >= 0 && hour <= 23 &&
      minute >= 0 && minute <= 59 &&
      repeatMask >= 0 && repeatMask <= 127 &&
      timeZoneId.trim().isNotEmpty &&
      snoozeMinutes >= 1 && snoozeMinutes <= 60;

  bool repeatsOn(int weekdayBit) =>
      weekdayBit >= 0 && weekdayBit <= 6 && (repeatMask & (1 << weekdayBit)) != 0;
}
