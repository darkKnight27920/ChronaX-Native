enum CapabilityState { available, granted, denied, restricted, unsupported, unknown }

class CapabilitySnapshot {
  const CapabilitySnapshot({
    required this.id,
    required this.state,
    required this.observedAt,
    this.reason,
    this.settingsAction,
  });

  final String id;
  final CapabilityState state;
  final DateTime observedAt;
  final String? reason;
  final String? settingsAction;

  factory CapabilitySnapshot.fromAndroid({
    required String id,
    required bool supported,
    required bool granted,
    required DateTime observedAt,
    String? reason,
    String? settingsAction,
  }) => CapabilitySnapshot(
        id: id,
        state: !supported
            ? CapabilityState.unsupported
            : granted
                ? CapabilityState.granted
                : CapabilityState.denied,
        observedAt: observedAt,
        reason: reason,
        settingsAction: settingsAction,
      );
}
