import 'package:flutter/widgets.dart';
import 'app/chrona_app.dart';
void main(){WidgetsFlutterBinding.ensureInitialized();runApp(const ChronaApp());}
