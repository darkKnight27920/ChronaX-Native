import 'package:flutter/material.dart';

/// Chrona-owned design tokens. Feature screens must consume these tokens rather
/// than defining competing radii, spacing, color or motion values.
abstract final class ChronaSpace {
  static const double xxs = 4;
  static const double xs = 8;
  static const double sm = 12;
  static const double md = 16;
  static const double lg = 22;
  static const double xl = 28;
  static const double xxl = 36;
}

abstract final class ChronaRadius {
  static const double control = 14;
  static const double card = 22;
  static const double hero = 30;
  static const double sheet = 30;
  static const double pill = 999;
}

abstract final class ChronaMotion {
  static const Duration immediate = Duration(milliseconds: 110);
  static const Duration control = Duration(milliseconds: 180);
  static const Duration surface = Duration(milliseconds: 280);
  static const Duration route = Duration(milliseconds: 340);
  static const Curve standard = Curves.easeOutCubic;
  static const Curve emphasized = Curves.easeInOutCubicEmphasized;
}

abstract final class ChronaPalette {
  static const Color accent = Color(0xFF8998F2);
  static const Color accentSecondary = Color(0xFF70C9C0);
  static const Color darkBackground = Color(0xFF0D1018);
  static const Color lightBackground = Color(0xFFF4F5F9);
}
