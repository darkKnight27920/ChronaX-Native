import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
/// Versioned, additive local-first storage. Unknown legacy keys are never deleted.
class LocalStore {
 static const schemaKey='chrona.schemaVersion', schemaVersion=2;
 static const settingsKey='chrona.settings.v2', alarmsKey='chrona.alarms.v2', tasksKey='chrona.tasks.v2', locationsKey='chrona.locations.v2';
 Future<void> migrate() async {
  final p=await SharedPreferences.getInstance(); final old=p.getInt(schemaKey)??0;
  if(old<1){for(final pair in {'settings':settingsKey,'alarms':alarmsKey,'tasks':tasksKey,'locations':locationsKey}.entries){if(!p.containsKey(pair.value)&&p.containsKey(pair.key)){final v=p.get(pair.key);if(v is String)await p.setString(pair.value,v);else if(v is bool)await p.setBool(pair.value,v);else if(v is int)await p.setInt(pair.value,v);else if(v is double)await p.setDouble(pair.value,v);else if(v is List<String>)await p.setStringList(pair.value,v);}}}
  if(old<2&&!p.containsKey('chrona.migration.v2'))await p.setString('chrona.migration.v2',DateTime.now().toUtc().toIso8601String());
  await p.setInt(schemaKey,schemaVersion);
 }
 Future<Map<String,dynamic>> readSettings() async {final p=await SharedPreferences.getInstance();final raw=p.getString(settingsKey);if(raw==null)return {};try{return Map<String,dynamic>.from(jsonDecode(raw) as Map);}catch(_){return {};}}
 Future<void> writeSettings(Map<String,dynamic> v) async {final p=await SharedPreferences.getInstance();await p.setString(settingsKey,jsonEncode(v));}
 Future<List<Map<String,dynamic>>> readRecords(String key) async {final p=await SharedPreferences.getInstance();final raw=p.getString(key);if(raw==null)return [];try{return (jsonDecode(raw) as List).map((e)=>Map<String,dynamic>.from(e as Map)).toList();}catch(_){return [];}}
 Future<void> writeRecords(String key,List<Map<String,dynamic>> v) async {final p=await SharedPreferences.getInstance();await p.setString(key,jsonEncode(v));}
}
