# Chrona X 7.1.0.10.00-release — Phase 2 Feature / Behavior Matrix

Status vocabulary is deliberately honest:
- **Implemented:** meaningful source behavior exists in this package.
- **Foundation:** architecture/data/UI boundary exists, but native or broader behavior is not complete.
- **Later validation:** intentionally left for full build/device validation.
- **Historical requirement:** must be preserved, but source evidence still needs implementation/verification.

| Area | Owner | Phase 2 status | Acceptance requirement |
|---|---|---|---|
| Home / clock | Flutter + Rust boundary | Implemented | Adaptive clock shell; no fixed 720×1600 assumption |
| Digital / analog / both | Flutter | Foundation | Real renderers + persisted preference; no mode silently dropped |
| World Clock | Flutter + timezone data | Implemented baseline | IANA zone drives displayed instant; never a frozen offset |
| Alarms | Flutter + Kotlin | Foundation | Persisted recurrence; native scheduling; lifecycle/reboot validation |
| Timer | Flutter + Rust timing model | Implemented baseline | Timestamp-derived elapsed/remaining state; UI timer cannot be the source of truth |
| Stopwatch / laps | Flutter + Rust timing model | Implemented baseline | Monotonic/timestamp-derived state; widget lifetime cannot reset timing |
| Tasks / reminders | Flutter | Implemented baseline | Persisted records and predictable completion/edit behavior |
| Focus / Pomodoro | Flutter | Foundation | Persisted phase/timing state and restoration |
| Intervals | Flutter + Rust timing model | Foundation | Deterministic phase transitions and restoration |
| Sleep | Flutter + Kotlin | Foundation | Native scheduling boundary; real background behavior validated later |
| Calendar | Flutter | Implemented baseline | Correct month/day calculation and adaptive grid |
| Notifications | Flutter + Kotlin | Foundation | Real permission/channel state; no fake success state |
| Time Zones | Flutter + timezone data + Rust where useful | Implemented baseline | IANA zone semantics, DST-aware |
| Date Calculator | Flutter + Rust | Implemented baseline | Deterministic date arithmetic |
| Meeting Planner | Flutter + Rust | Foundation | Explicit overlap semantics and timezone conversion |
| Time Difference | Flutter + Rust | Implemented baseline | Correct signed difference semantics |
| Day Counter | Flutter + Rust | Implemented baseline | Inclusive/exclusive convention documented in UI |
| More sheet | Flutter | Implemented baseline | Native drag/snap/dismiss; single navigation owner |
| Settings hierarchy | Flutter | Implemented baseline | No nested duplicate Settings menu; adaptive text scale |
| Localization | Flutter | Foundation | Centralized locale state + persistence; complete coverage requires audit |
| Developer Options | Flutter | Implemented | Hidden until deliberate seven-tap unlock; advanced content gated |
| Changelog | Flutter | Implemented baseline | Historical records preserved; advanced technical view gated |
| About | Flutter | Implemented baseline | Chrona identity + native architecture details; no Xiaomi clone |
| Install surfaces | Flutter | Foundation | Describes native Android and separate web targets accurately |
| Continuum / diagnostics | Flutter + native boundaries | Foundation | Reports declared capability/validation state without fake completion |
| Quick Glance | Flutter | Implemented baseline | Large cards remain useful and compact enough for phone layouts |
| Mini Widgets | Flutter | Implemented baseline | Configurable data-driven widgets; no decorative-only controls |
| Language switching | Flutter | Foundation | Real persisted app state; untranslated coverage must be audited |
| Native ringtone/audio | Kotlin | Later validation | Real Android implementation + audio-focus tests |
| Exact alarms/background | Kotlin | Later validation | Permission/policy + Doze/reboot/killed-process tests |
| APK/AAB | Flutter/Android toolchain | Later validation | Build/sign/install; not claimed here |


## Additional ecosystem and platform systems

| Area | Owner | Status | Acceptance requirement |
|---|---|---|---|
| Chrona Studio | Flutter + design tokens | Planned | Real runtime customization; no decorative controls |
| Profiles | Flutter + SQLite | Planned | Versioned named profiles with safe merge/restore |
| Data Vault export/restore | Drift/SQLite + Flutter | Planned | Preview, integrity checks, additive restore, rollback point |
| Capability Registry | Kotlin + Flutter | Foundation | Real observed state, reason and refresh time |
| Diagnostics/App Health | Flutter + Kotlin | Foundation | Redacted actionable reports and targeted recovery |
| Migration Center | Drift/SQLite | Planned | Additive versioned migrations with fixtures |
| Chrona API | Future backend | Planned | Versioned, documented and authenticated contracts |
| Chrona Sync | Future backend + crypto | Future | Optional encrypted conflict-aware sync; offline core preserved |
| Chrona ID | Future identity service | Future | Optional account; never required for core clock functions |
| Regional Editions | Shared core + policy packs | Planned | Global/China/Regional differences isolated from core semantics |
| Chrona Update | Signed metadata + platform distribution | Planned | Verify release metadata; no untrusted executable updates |
| Compatibility Center | Kotlin + Flutter | Planned | Truthful API/device capability matrix |

The original feature status labels above are conservative source classifications. The current native UI is still an engineering shell, not a completed feature implementation.
