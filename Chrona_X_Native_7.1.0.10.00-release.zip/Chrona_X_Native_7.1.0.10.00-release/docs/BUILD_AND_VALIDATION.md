# Build and validation

The public product version is locked to `7.1.0.10.00-release`. Android uses a separate monotonic `versionCode` (`71010000` proposed for the first native package). The candidate package ID is `com.chronax.clock`; treat it as permanent after first store publication.

Google Play new app/update submissions require target API 36 from 31 August 2026. This project therefore targets/compiles against API 36 and requires AGP 8.9.1 or newer. Android NDK r28+ is required for default 16 KB ELF alignment of native libraries.

## Build stages
1. Import the repository into GitHub/Codemagic.
2. Install the stable Flutter SDK, Java 17, Android SDK 36 and NDK r28+.
3. Install Rust stable and Android targets (`aarch64-linux-android`, `armv7-linux-androideabi`, `x86_64-linux-android`).
4. Build Rust libraries, run Rust tests, then Flutter analyze/tests and Kotlin/Gradle checks.
5. Build a debug APK for internal testing.
6. Configure owner-controlled signing material in secure CI storage before release APK/AAB builds. Never commit keystores or credentials.
7. Verify package ID, versionName/versionCode, signature, ABI libraries and 16 KB alignment.
8. Install/update on the Redmi 13C and run the physical-device matrix.

## Current gates
Flutter/Dart, Rust, Kotlin and Gradle toolchains were not available in the source-editing environment. No build, APK, AAB, signature or device test is claimed. See `APK_BUILD_AND_RELEASE_GATES.md` and `DEVICE_PROFILE_AND_TEST_PLAN.md`.
