# Chrona X defect-to-owner traceability

| Reported failure / requirement | Authoritative owner | Current source evidence | Acceptance evidence still required |
|---|---|---|---|
| Header/footer collapse, vertical text, misplaced arrows | Flutter adaptive layout/components | Responsive design-system token foundation only | Widget/golden tests at narrow widths and text scales |
| Home clipping, overlays, bad spacing/radii | Flutter Home/layout owner | New token contract; full Home redesign incomplete | Visual and interaction review on phone/tablet |
| Competing routes/state/renderers | App router + Riverpod/domain repositories | Architecture contract; migration incomplete | Route/state ownership tests |
| Feature-specific overflow menus and More drag/snap | Feature UI + single navigation owner | Acceptance requirements recorded | Gesture/integration tests |
| Fake/static blur and vignette dependencies | Design-system material/effect owner | Material contract documented; runtime effects not implemented | Device GPU and dependency-state tests |
| Slider thumb/progress mismatch | Shared Chrona slider component | Token contract only | Golden + drag + disabled-state tests |
| Settings groups/scroll/persistence | Settings feature + local repository | SharedPreferences migration foundation | SQLite migration, scroll and persistence tests |
| Sound/notification permission false status | Kotlin capability adapter | Real notification/exact-alarm state query and request entry points added | API 33–36 grant/deny/revoke device tests |
| Wrong ringtone/system settings path | Kotlin audio/intent adapter | Settings routes added; ringtone picker/playback incomplete | URI persistence, audio-focus and missing-handler tests |
| Exact alarms, repeat, reboot/timezone reconciliation | Kotlin AlarmManager adapter | Weekly mask, setAlarmClock, boot/time/timezone/permission receiver foundation | Canonical DB sync, snooze, process-death/Doze/HyperOS tests |
| Timer/stopwatch lost on widget disposal | Rust timing core + persisted timestamp state | Rust elapsed/remaining/signed arithmetic added | UI integration and lifecycle tests |
| Date calculator/time difference overflow | Rust deterministic core | Gregorian day distance and saturating arithmetic added | Rust tests must run in CI; Dart bridge parity tests |
| Recovery mode did nothing | App Health + targeted recovery | Architecture/diagnostics contract | Fault injection and targeted reset tests |
| Continuum fake statistics | Capability registry + diagnostics | Typed capability model foundation | Runtime-backed status and failure evidence |
| Developer Options gate broken | Flutter developer gate | Requirement retained in feature registry | Seven-tap lock/unlock widget tests |
| About/changelog incomplete | Product metadata + release ledger | Version authority and engineering docs | UI, archive completeness and gate tests |
| Localization selector decorative | Flutter gen-l10n + persisted locale | Architecture requirement only | Locale coverage and persistence tests |
| Data loss during rebuild/migration | SQLite/Drift repository + Data Vault | Current SharedPreferences v2 only; Drift not implemented | Legacy fixture migration/export/restore tests |
| Public source/signing secret risk | GitHub/CI secret management | `.gitignore`, public repo rules and release gates | Repository secret scan and signing audit |
| Battery/GPU/jank/thermal regressions | Flutter rendering + Android profiling | Redmi 13C test plan | Physical 60/90 Hz, thermal and battery traces |
| Android 16/API 36 and 16 KB page-size | Gradle/NDK/Rust packaging | API36/AGP8.9.1/NDK28 configuration | Successful CI build and alignment verification |

A source file or requirement row is not a passing test. The final column is mandatory before release acceptance.
