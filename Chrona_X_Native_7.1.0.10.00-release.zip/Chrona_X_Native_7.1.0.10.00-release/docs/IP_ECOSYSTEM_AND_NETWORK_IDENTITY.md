# Chrona X product IP, ecosystem and network identity

## 1. Two meanings of IP

Chrona X has two distinct IP concepts that must not be confused:

- **Intellectual property:** the Chrona X name, identity, original clock mark, visual language, software, product architecture, documentation and future product family.
- **Internet Protocol identity:** DNS names, IPv4/IPv6 addressing, TLS endpoints, API hosts and infrastructure used by online services.

The first is a product/brand ownership matter. The second is a networking/hosting design matter. Neither implies that a trademark, domain or public IP address has already been registered.

## 2. Master product hierarchy

```text
CHRONA X — MASTER SOFTWARE IP
│
├── Chrona X Core
│   ├── time and domain contracts
│   ├── shared data/state schemas
│   ├── design tokens and motion contracts
│   ├── capability registry
│   ├── migration and compatibility framework
│   ├── diagnostics and recovery contracts
│   └── extension/API contracts
│
├── Flagship products
│   ├── Chrona X Clock       native Android flagship
│   ├── Chrona X Web / PWA   independent web delivery
│   ├── Chrona X Mobile      future cross-mobile family
│   ├── Chrona X Desktop     future desktop delivery
│   └── Chrona X Wear        future wearable companion
│
├── Shared platform services (future, optional)
│   ├── Chrona ID            account/identity, only if needed
│   ├── Chrona Sync           encrypted cross-device sync
│   ├── Chrona API            documented versioned service boundary
│   ├── Chrona Studio         customization and profiles
│   ├── Chrona Extensions     scoped, signed integrations
│   └── Chrona Update         verified update/release metadata
│
└── Editions
    ├── Global
    ├── China
    └── Regional policy/configuration packs
```

The products share identity and compatible core contracts, not necessarily every screen or feature. Editions can vary service providers, legal requirements, integrations, availability and regional infrastructure without forking the master identity.

## 3. Local-first and account strategy

- Chrona Clock must remain useful offline and without a Chrona account.
- Do not add mandatory sign-in for alarms, timers, stopwatch, World Clock or core local features.
- Chrona ID is a future optional service, not a prerequisite for app use.
- Chrona Sync must be opt-in, encrypted, conflict-aware and transparent about data stored remotely.
- User data export/import and local backup must exist independently of cloud sync.
- No analytics or behavioural tracking by default. Any future diagnostics upload requires explicit, informed consent and redaction.

## 4. Internet Protocol address and DNS policy

No public IP address is assigned to Chrona at this stage. Do not invent one or hard-code a cloud provider's current address.

When online services are commissioned:

- Register and verify a domain controlled by the product owner before publishing endpoints. Candidate domains must be availability-checked and ownership-confirmed first.
- Use stable DNS hostnames, not literal IPs in apps. Proposed logical names: `api.<owned-domain>`, `updates.<owned-domain>`, `cdn.<owned-domain>`, `status.<owned-domain>`.
- Use HTTPS/TLS with managed certificate renewal; support IPv4 and IPv6 where the hosting stack allows.
- Put API traffic behind a managed load balancer/API gateway and CDN/WAF as appropriate. Public service IPs may change; DNS is the stable contract.
- Use static IPs only when a specific allowlisting/hosting requirement justifies them. If required, allocate them through the chosen cloud provider and document ownership, region, failover and renewal.
- Never ship a development/private LAN address (`192.168.x.x`, `10.x.x.x`, `172.16/12`) or a developer's personal public IP in production config.
- Never embed API secrets, signing keys, private certificates or service credentials in the APK or public Git repository.
- Use environment-specific configuration for local, staging and production. Production endpoint changes require a reviewed release.

## 5. API and regional topology

- Version APIs explicitly, e.g. `/v1`, and keep compatibility/deprecation policy documented.
- Separate public app metadata/update manifests from authenticated user-data APIs.
- Apply rate limits, abuse controls, request validation, audit logs and data minimization.
- Use regional data placement and provider selection according to verified legal/platform requirements. Do not assume Global infrastructure can serve every China/Regional edition.
- Regional policy packs may alter service endpoints, consent text, feature availability and compliance settings, but cannot fork core time/date semantics or Chrona identity.
- Keep secrets in a server-side secret manager, never in client configuration.

## 6. Public repository and source/IP protection

The user selected a public GitHub repository. Public means source, commit history and every future pushed file are visible to everyone.

- Do not commit keystores, passwords, API tokens, private signing certificates, personal contact details, private user data, production logs or unreleased credentials.
- Do not upload the master logo source or other sensitive original assets unless the owner intentionally chooses to publish them.
- Add a clear copyright/rights notice. Public visibility does not automatically grant others a licence to reuse the source; do not add an open-source licence without the owner's decision.
- Keep third-party dependency notices and licences in a notices inventory before distribution.
- Preserve original Chrona logo/clock mark; no generated replacement, redraw or derivative without explicit approval.
- Trademark availability, registration and ownership require separate legal/registry checks. This document does not claim registration.

## 7. Package and signing identity

- Current Android candidate ID: `com.chronax.clock`.
- Treat `applicationId` as permanent after first store publication. Do not casually rename it.
- Product display name: `Chrona X`.
- Public version name remains `7.1.0.10.00-release`.
- Android `versionCode` must increase monotonically for every store upload, independent of the user-facing version string.
- Generate an owner-controlled upload/signing key. Keep at least two secure offline backups. Never commit it or put it in a public artifact.
- Prefer Google Play App Signing for Play distribution, with owner-controlled upload key custody. Direct APK distribution requires a consistent signing identity for updates.

## 8. Future expansion gates

Do not build cloud/account/extension services before there is a real use case, threat model, privacy policy, data schema, hosting budget and support model. The architecture should reserve clean boundaries now, while keeping the first native Clock useful, fast and offline.
