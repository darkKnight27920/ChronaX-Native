# Chrona X — Master DeepSeek Handoff (Consolidated)

## 0. Purpose
This is the single consolidated handoff for the later DeepSeek co-development phase. Do not ask the user to re-explain the project. It supersedes the separate handoff/contract documents for execution, while preserving their requirements and provenance.

## 1. Exact release identity — NON-NEGOTIABLE
- Current version: **7.1.0.10.00-release**.
- Do **not** jump to 8.x, 9.x, or any other major version.
- Do not revive the old rule excluding 7.1.x; the user's current identity is explicitly 7.1.0.10.00-release.
- Preserve release discipline. Do not silently promote a build to a new stage or release identity.

## 2. Architecture — actual native app
- UI/application layer: **Flutter + Dart**.
- Native deterministic/timing/core layer: **real Rust**.
- Android platform integration: **real Kotlin** adapters/services where required.
- Use a clear FFI/platform boundary; Rust must not be a decorative scaffold.
- No HTML/JavaScript application shell.
- No browser runtime presented as the native Android app.
- Web/PWA can exist as a separate delivery surface, but it is not the native implementation.
- Historical HTML/JS builds are requirements/reference evidence only; do not copy their source into the new runtime.

## 3. Product identity and restoration
Chrona X is not a new product. Preserve the Chrona X identity, original clock mark/brand assets, naming, feature concepts, historical mechanisms, and documented behavior while implementing them independently in the new architecture.

Preserve unless the user explicitly removed it:
- Clock: digital / analog / both.
- World Clock, saved locations, local-time conversion, day/night vocabulary, analog faces.
- Alarms: repeat days, labels, snooze, ringtone/audio model, volume controls.
- Timer, presets, countdown.
- Stopwatch and laps.
- Tasks / reminders.
- Focus.
- Pomodoro.
- Intervals.
- Sleep / bedtime.
- Calendar.
- Notifications.
- Time Zones.
- Date Calculator.
- Meeting Planner.
- Time Difference.
- Day Counter.
- More feature library.
- Settings hierarchy.
- About.
- What's New / complete changelog archive.
- Install surfaces.
- Continuum / Data Vault / App Health / extensions / command/capability concepts.
- Quick Glance.
- Mini Widgets and customization.
- Language switching.
- Persistent user data/state migration concepts.

Historical removals are regressions unless the user explicitly removed the feature.

## 4. New UI direction
- Build a genuinely new UI. Do not revert to the old Chrona UI merely because an older build was more reliable.
- Historical builds such as 3.x, 5.8 and 6.x are reference sources for proven behavior, geometry, interaction, and requirements — not visual templates to blindly restore.
- Keep Chrona's own identity and information architecture.
- Xiaomi Clock / HyperOS / One UI / Material 3 Expressive are inspiration for motion, hierarchy, polish, and useful interaction patterns only. Do not clone Xiaomi layouts.
- The result must feel like a real native app, not a document, web page, or generic settings mockup.

## 5. Interaction requirements
- One navigation owner.
- No stacked/competing route handlers, transition collisions, duplicate page owners, dead clicks, disappearing controls, giant overlays, or delayed navigation masquerading as animation.
- Immediate press feedback.
- Subtle but deliberate M3 Expressive-style motion.
- Major and minor transitions should be coherent and purposeful.
- Feature-specific overflow menus on applicable screens; Home and Settings are exceptions where previously specified.
- Each feature menu should contain useful, feature-specific actions.
- Settings subpages must not put a redundant Settings menu inside their own overflow menu.
- Classic left-to-right looping chevrons must be restored where appropriate.
- Belt icons remain still at rest and use distinct tap animations per feature/icon.
- Logo/icon tap behavior should respond immediately and not require an artificial close step.
- More sheet retains the known-good drag/snap interaction concept but is reimplemented natively.
- Preserve the slider geometry/interaction concept and active-state feedback.
- Respect reduced-motion preferences.

## 6. Adaptive layout
Design and implementation must work across:
- Portrait and landscape.
- Different screen sizes/aspect ratios.
- System display scaling.
- System text/font scaling.
- Safe-area and gesture insets.
- Narrow 720px-class screens without hard-coded assumptions.
- Larger screens without becoming a stretched phone mockup.

Do not use fixed 720×1600 assumptions as the layout model.

## 7. Developer Options / diagnostics
- Developer Options are not visible/active while locked.
- Seven-tap unlock is a deliberate app feature, not the system Android developer-options page.
- Advanced changelog is gated behind Developer Options.
- Developer diagnostics may expose route/state/layout/safe-area/performance/motion inspection, but must not affect normal users when locked.
- Never implement the previous broken behavior where tapping the Developer Options row immediately opens the page and then requires seven taps.

## 8. About / What's New
About should combine Chrona's actual identity/details with the information architecture of a polished phone Settings "About" page, without copying Xiaomi's exact UI.

What's New requirements:
- Basic changelog visible normally.
- Advanced technical/internal changelog visible only after Developer Options unlock.
- Preserve historical release records accurately.
- Do not invent missing historical entries or pretend an unverified detail is documented.
- Preserve old changelog material as source evidence where available.

## 9. Language system
Language switching must be real application state, not a decorative selector.
- Centralized localization state.
- Persistent language preference.
- UI updates consistently across screens.
- Avoid leaving untranslated strings in core surfaces.
- Do not claim complete localization coverage until verified.

## 10. Data and state
- Local-first state where appropriate.
- Additive migration: never wipe existing user data simply because the UI/runtime was rebuilt.
- Explicit versioned storage boundaries.
- State restoration across navigation and lifecycle changes.
- Separate UI state, persisted product state, timing state, and platform state.

## 11. Timing / alarms / notifications
Architecture should be designed for real native behavior:
- Rust may own deterministic time calculations/timer state where appropriate.
- Kotlin/Android owns Android lifecycle, notifications, alarm scheduling, channels, exact-alarm integration, audio/ringtone integration, and platform policy boundaries.
- Flutter owns presentation and user interaction.
- Do not fake background execution with a foreground UI timer.
- Do not claim alarms work in killed/background states until validated on hardware.

## 12. Plugin/tool ecosystem — Phase 2
Use the available tools where they materially improve the work, not as a checklist stunt.

### Figma
Use for:
- Native UX system exploration.
- Screen/state/component architecture.
- Adaptive layout planning.
- Motion/interaction reference capture.
- Design-to-code validation.
- Reviewing the Phase 2 UX system created for Chrona X.
Do not use it to clone Xiaomi layouts.

### GitHub
Use for:
- Official/reference implementation research.
- Native Android/Flutter/Rust integration patterns.
- Source/project organization where an actual repository is available.
Do not invent repository evidence when search results are empty.

### Canva
Use only for useful brand/visual artifacts or presentation/review material.
- Never redraw, replace, OCR, reconstruct, or alter the Chrona master logo without authorization.
- Existing Canva search returned no Chrona X design, so do not pretend Canva contains the master asset.

### Outliner
Use for large requirements/feature decomposition and keep the complete tree intact.

### Runway
Use only for useful visual/motion exploration.
- Never substitute generated assets for Chrona's actual assets.
- Never fabricate reference evidence.

### Descript / Yaps
Use only if source recordings are actually available and need analysis/captioning.
- Preserve originals.
- If a required user recording is missing, do not pretend it was inspected.

### TubeAlfred / vidIQ / Spotify
Use only if a concrete audio/media research or workflow requirement benefits from them. Do not invoke them merely to satisfy a plugin count.

### Plugin Management
Discover additional integrations only when a concrete Chrona requirement is not otherwise covered. Never claim a plugin is installed/connected/used without verification.

## 13. What DeepSeek should execute later
Leave the following to DeepSeek because they require an Android/Flutter build environment, device access, or native validation not honestly available here:
- Android SDK / Gradle / NDK environment setup.
- Full Flutter build tooling setup where unavailable.
- APK/AAB compilation, signing, installation and packaging validation.
- Physical Redmi 13C profiling at 60/90 Hz.
- GPU/raster/jank traces and thermal/performance profiling.
- Real alarm/background execution verification across lifecycle states.
- Exact alarm permission/policy verification on the target Android version.
- Notification channel behavior verification.
- Ringtone/audio focus/background playback verification.
- Generated Flutter↔Rust FFI bindings and complete native packaging when the local environment cannot build them.
- Final hardware accessibility, text-scale, orientation and safe-area validation.
- Any source-level validation that requires unavailable SDK/toolchain capabilities.

DeepSeek is a later co-dev executor, not a substitute for this architecture or a reason to leave obvious work unfinished.

## 14. What this Phase 2 assistant work should finish before handoff
- Consolidate requirements and eliminate contradictions in the handoff.
- Keep version identity fixed at 7.1.0.10.00-release.
- Establish the native UX system and component/state map.
- Research and document native implementation patterns.
- Identify historical behavior worth preserving from the Library.
- Keep the project architecture honest: no fake native claims.
- Prepare precise implementation boundaries for Flutter, Rust and Kotlin.
- Produce reviewable design/research artifacts where tools can genuinely add value.
- Record exactly what was verified and what remains for DeepSeek.

## 15. Verification standard
Before calling a Phase 2 item complete:
1. Check the changed item itself.
2. Check surrounding layout/state/navigation/dependencies.
3. Check the likely regression paths.
4. Compare against known-good historical behavior where relevant.
5. Confirm no version drift.
6. Confirm no fake/placeholder functionality was introduced.
7. Confirm the change remains consistent with Flutter/Dart + Rust + Kotlin architecture.

## 16. Hard prohibitions
- No 8.x jump.
- No generic HTML/JS rebuild presented as the native app.
- No arbitrary UI churn.
- No placeholder controls or empty fake features.
- No copying old Chrona source into the new runtime.
- No silent deletion of existing features.
- No fabricated testing, screenshots, device results, compilation results, or plugin usage.
- No pretending a generated visual is an original Chrona asset.
- No claiming DeepSeek completed work it has not completed.
- No release promotion without the required validation/approval path.

## 17. Phase 2 research decisions captured now
The following implementation decisions are grounded in current Flutter/Android/Material guidance and the Phase 2 research pass:

- Flutter remains the presentation/interaction owner; keep domain state separate from widgets and platform state.
- Rust should expose a small, typed domain API rather than leaking platform concerns into the core. Generated typed FFI is preferred when the build environment supports it.
- Kotlin owns Android lifecycle-sensitive behavior: alarm registration/reconciliation, notification channels, exact-alarm capability, ringtone/audio focus, reboot/timezone/package-change reconciliation, and other Android policy boundaries.
- Alarm scheduling must be idempotent and reconcilable. A persisted Chrona alarm is the source of truth; native registrations are derived state that can be recreated after reboot, timezone changes, permission changes, or process death.
- Exact-alarm capability must be represented explicitly in product state. Do not silently assume exact scheduling is available on modern Android.
- Timer/stopwatch duration semantics must not depend on a Flutter widget remaining alive. Persist start/target timestamps or monotonic-domain state as appropriate and derive presentation from them.
- World Clock should calculate the displayed instant/offset from the selected IANA time zone rather than storing a permanently fixed offset.
- Accessibility is part of the component contract: semantic labels, meaningful grouping, large text support, usable touch targets, reduced motion, and accessible native alarm/ringing actions are requirements, not post-build decoration.
- Material 3 Expressive should be treated as a centralized token/component system. Do not scatter colors, radii, motion timings, or typography literals through screens.
- Historical behavior should be converted into observable compatibility tests: alarm create/edit/disable/re-enable/snooze, timer wall-clock changes, world-clock timezone changes, navigation, state restoration, and migration are all explicit contracts.
- UI redesign must not silently change domain meaning, recurrence, timing, dismissal, persistence, or native scheduling behavior.

## 18. Phase 2 evidence/tools actually used
- **Figma:** created the native UX-system design file: `Chrona X 7.1.0.10.00-release — Phase 2 Native UX System`.
- **Outliner:** generated the Phase 2 execution blueprint covering release governance, native architecture, preserved product surfaces, motion, adaptive reliability, research evidence, and the later DeepSeek boundary.
- **Canva:** searched the connected Canva designs for `Chrona X`; no matching design was returned. Therefore no Canva asset was treated as the Chrona master asset.
- **Runway:** connection/workspace availability was checked. Image generation models are available, but no visual asset was generated because doing so would risk substituting invented visuals for Chrona's actual identity; video generation is not available in the current workspace.
- **GitHub:** searched for implementation references. Search results were noisy for broad generic queries, so no third-party repository was adopted as authoritative project evidence.
- **Liner:** used for a high-effort architecture/reliability research pass spanning Flutter architecture, Rust FFI, Android alarms, accessibility, Material 3 Expressive, and clock/alarm ecosystem references.

## 19. Research boundary / unresolved verification
The research establishes architecture and acceptance criteria; it does not prove hardware behavior. APK/AAB compilation, Android exact-alarm permission behavior on the target device, background/killed-process alarms, audio focus/ringtone behavior, GPU performance, and final accessibility/orientation validation remain DeepSeek/device-validation work.

## 20. Figma Phase 2 artifact
Figma file created for this phase:
`https://www.figma.com/design/rUMDmuaWh5ehDhCDvjai96`

Use this as the design-system/UX review surface. Do not treat it as permission to clone another product's layout.
## 21. Phase 2 source changes already completed in this package
These are **assistant-completed source/design changes**, not DeepSeek tasks:
- corrected all active product identity references to `7.1.0.10.00-release`;
- separated product release identity from package-semver (`7.1.0+710000`);
- added `lib/core/release_identity.dart` as the single product identity source;
- added versioned local persistence for settings, locations, alarms and tasks;
- added a centralized localization registry and connected the app locale to persisted language state;
- added timestamp-derived Rust elapsed/remaining primitives and unit tests;
- added a real Kotlin capability bridge reporting exact-alarm and notification state without pretending scheduling/audio are finished;
- removed the redundant `USE_EXACT_ALARM` declaration until the actual Android policy/use-case is validated;
- replaced the old Continuum diagnostic wording that incorrectly described a `7.1.x` branch as excluded;
- expanded the feature matrix so source foundations are not mislabeled as complete native behavior;
- created `PHASE2_EXECUTION.md` and `PLUGIN_EVIDENCE.md` to keep the execution record auditable.

## 22. Current validation caveat
The above source changes were inspected statically. Because this environment still lacks the full Flutter/Dart/Rust/Android toolchain and target device, **they have not been compiler-validated here**. DeepSeek must run the actual analyzer/tests/build/device validation before treating them as release-grade.

## 23. Canonical handoff rule
If any older DeepSeek handoff contradicts this file, this master handoff wins. Do not maintain multiple competing task lists.

# 24. CRITICAL USER CORRECTION — DO NOT REVERT THE PRODUCT

This section supersedes any implementation choice that interpreted “rebuild” as “return Chrona to 6.12.x.”

The user explicitly rejected the previous assistant action because it effectively reverted Chrona to the 6.12.x state and therefore removed features, mechanisms and work introduced after 6.12.x. **That must never happen again.**

## 24.1 Current public version is LOCKED

- Current public version: **7.1.0.10.00-release**
- Do not change it unless the user explicitly authorizes a version-number change.
- `-release` is mandatory.
- Never silently introduce a new major/minor/version scheme.
- The user's current version-system preferences must be respected independently of any internal build/codename identifiers.

## 24.2 6.12.x is a VISUAL/PRODUCT BASELINE, NOT A REVERT TARGET

6.12.x is the approved reference/foundation for the Chrona visual direction and important working feature surfaces.

It is NOT permission to:
- delete later features;
- revert Chrona to an old snapshot;
- remove later runtime mechanisms;
- remove later interaction systems;
- remove later pages;
- remove later changelogs;
- discard later architecture;
- replace the current product with an old HTML artifact.

The correct operation is:

**preserve the cumulative current product → identify what is broken/conflicting → repair/rework ownership → retain later additions → improve them → remove only genuine duplicates/conflicts.**

## 24.3 Chrona is a cumulative product

The user expects the current version to contain the useful cumulative work from the later 7.1.x iterations and earlier versions. A rebuild must therefore be an integration/reconstruction of the accumulated product, not a rollback.

The 6.12.x UI is the protected design reference. Later features and mechanisms remain unless explicitly rejected by the user or proven to be duplicate/broken/conflicting.

# 25. COMPLETE PRODUCT/IP DIRECTION

Chrona X is not merely “a web clock.” It is its own software product IP.

The intended architecture is:

Chrona X (parent product IP)
- Chrona X Core
- Chrona X Clock (flagship)
- Chrona X Web / PWA
- Chrona X Mobile / native application
- future Desktop/Wear/other products where justified
- Global Edition
- China Edition
- future Regional Editions

Different products and regional editions may have different capabilities, services, APIs, distribution and UI adaptations while remaining part of the same Chrona X IP.

The HTML/PWA is a real Chrona X product delivery while the native app is being developed. It is not a throwaway prototype or generic placeholder.

Reference products such as Xiaomi/HyperOS, Android, One UI, iOS, Material 3 Expressive and Xiaomi Clock are **quality/interaction references**, not assets or UI to clone. Chrona must retain its own identity.

# 26. NON-NEGOTIABLE DEVELOPMENT PHILOSOPHY

The user means “everything” literally when requesting a full rebuild/rework. Scope includes both obvious and tiny details:

- layout
- hierarchy
- spacing
- padding
- sizing
- alignment
- typography
- wrapping
- icon geometry
- shapes/radii
- separators
- shadows
- transparency
- live blur
- glass/material response
- vignette
- lighting
- fades
- transitions
- opening/closing motion
- easing
- press feedback
- release feedback
- hover/pointer behaviour where applicable
- touch
- swipe
- drag
- gestures
- scroll
- overscroll
- focus
- keyboard/input behaviour
- tooltips
- menus/sheets/dropdowns
- notifications
- permission flows
- external-system paths
- PWA behaviour
- storage
- recovery
- diagnostics
- error handling
- state synchronization
- responsiveness
- performance
- smoothness
- stability
- accessibility
- reduced motion
- orientation/safe areas
- every feature's micro/macro interaction behaviour.

“Improvement” does not mean redesigning everything. Preserve the base UI and identity unless the user explicitly requests a redesign. Prefer precise rework/tweaks where something already has the correct concept but poor implementation.

# 27. NO COMPETING AUTHORITIES

Strict architecture rule:

- one clear purpose;
- one clear owner;
- one authoritative implementation;
- one state owner;
- one rendering owner per surface;
- one motion owner per interaction class;
- one material/blur owner;
- one dependency/state contract;
- one navigation authority;
- one release identity authority.

Do NOT solve bugs by appending another late CSS/JS override that competes with the old one.

Do NOT preserve duplicate mechanisms merely because they are old.

Do NOT remove working functionality merely to simplify the code.

Instead, trace the existing owner, consolidate genuine duplicates, and migrate callers to the surviving owner.

# 28. PRESERVE ALL LATER FEATURES

A future rebuild must explicitly inventory the current feature surface before modifying it. At minimum, account for:

- Clock/time display
- Alarm
- World Clock
- Timer
- Stopwatch
- Pomodoro
- Intervals
- Sleep/planning tools
- Tasks/productivity mechanisms
- Widgets/Quick Glance/Mini Widgets where present
- Continuum
- Developer Options
- About
- Changelog / release history
- PWA/install behaviour
- customization
- blur/material settings
- vignette
- separators/fades
- feature-specific overflow menus
- external app/system integrations
- permission requests
- sound/ringtone selection
- notification permission
- any later mechanisms already introduced into 7.1.x

This list is a floor, not a complete inventory. Inspect the actual current artifact and historical artifacts/library records before claiming completeness.

# 29. EXTERNAL PATHS AND PERMISSIONS

Every Chrona feature that leaves Chrona or requests an OS/browser capability must have a real, verified path.

Examples already identified as broken in earlier iterations:
- “Choose alarm ringtone…” going to the wrong destination;
- notification permission merely reporting “permission denied” instead of actually requesting permission;
- sound permission/settings UI missing or fake;
- external settings/app paths broken or pointed at wrong routes;
- integrations that looked functional but did nothing.

Required architecture:

1. detect capability;
2. determine whether permission is required;
3. request it through the real supported API when possible;
4. explain unsupported cases honestly;
5. expose retry/open-settings fallback where the platform supports it;
6. never fake success;
7. never claim a browser API is equivalent to native OS capability.

Create a dedicated, real Sound/Audio permission/settings surface and place Notification permission immediately below it as previously requested, while keeping them under the appropriate platform capability owner.

# 30. LIVE MATERIAL / BLUR REQUIREMENTS

Blur must be genuinely live where the platform supports live backdrop filtering.

Do not use:
- a static blurred image pretending to be live blur;
- a captured background pretending to update;
- a generic translucent overlay as a substitute for blur.

Required behaviour:
- live background relationship;
- live foreground/material response;
- proper alpha hierarchy;
- correct blur radius response;
- correct saturation/light treatment;
- stable rendering under scroll and motion;
- graceful fallback when backdrop-filter is unavailable;
- fallback must not become ugly excessive transparency.

When Blur is OFF:
- blur-dependent controls are grey;
- controls are disabled/inert;
- they cannot be adjusted;
- the visual material changes coherently rather than leaving an overly transparent glass layer.

The same dependency model applies to Vignette and other parent/child settings.

# 31. SLIDERS / TOGGLES / DEPENDENT CONTROLS

Every slider must have:
- correctly sized thumb;
- track proportional to its actual control;
- filled progress region ending in geometry that matches the thumb/track language;
- immediate visual response;
- correct value synchronization;
- disabled state when its parent feature is OFF;
- no phantom movement or delayed state.

Toggles must change state immediately when tapped.

The same immediate-state principle applies to buttons, arrows, segmented controls, menus, checkboxes and every interactive control.

# 32. HEADER / FOOTER / SETTINGS GEOMETRY

Chrona previously suffered repeated regressions such as:

- headings becoming `A L A R M` vertically;
- arrows appearing underneath text rather than beside it;
- text moving to the right unexpectedly;
- widths shrinking unexpectedly;
- header/footer structures changing between pages;
- duplicate layers covering content;
- headings appearing above/inside an unintended transparent layer;
- inconsistent padding and spacing;
- controls leaving their intended positions.

Required approach:

Use explicit component geometry contracts and shared layout primitives rather than page-specific emergency offsets.

Header:
- navigation/back slot;
- title/subtitle content slot;
- optional contextual action slot;
- fixed logical order;
- no character-level wrapping;
- safe responsive constraints.

Footer/bottom belt:
- protected app navigation structure;
- no accidental webpage-footer behaviour;
- consistent safe-area handling.

Settings:
- predictable section grouping;
- deliberate information hierarchy;
- reasonable spacing;
- clear dependency relationships;
- consistent control alignment;
- responsive at the user's actual small mobile viewport.

# 33. THREE-DOT / CONTEXTUAL MENU

The three-dot button is a core Chrona interaction pattern.

Rules:
- top-right placement where appropriate;
- unique menu contents according to the feature/screen it belongs to;
- preserve existing useful actions;
- remove only the useless “Add to belt” action as previously specified;
- do not make every screen use the exact same menu;
- menu opening/closing motion must feel feature-appropriate;
- interactions must be immediate;
- menu must not cover unrelated UI incorrectly;
- placement must remain stable across viewport sizes.

Reference quality target: Xiaomi HyperOS Clock-style responsiveness and choreography, without copying Xiaomi's identity.

# 34. MOTION / INTERACTION SYSTEM

Every feature/action may have its own choreography while sharing underlying timing/easing infrastructure.

Required distinction:
- animation = property change choreography;
- effect = visual/material response;
- transition = state/page/context change.

These should not all be the exact same generic fade.

Support:
- page opening;
- page closing;
- sheet opening/closing;
- menu opening/closing;
- button press/release;
- toggle state change;
- slider movement;
- swipe;
- gesture;
- scroll-linked movement;
- tooltip appearance/disappearance;
- notification appearance/disappearance;
- contextual action transitions;
- navigation transitions;
- modal transitions;
- material/blur response;
- vignette response.

Use shared motion primitives but feature-specific choreography. Avoid a giant global animation override.

# 35. SMOOTHNESS / STABILITY

“Smooth” means more than animation duration.

Chrona must minimize:
- layout thrashing;
- unnecessary DOM reflow;
- repeated style recalculation;
- redundant event listeners;
- duplicate state updates;
- animation conflicts;
- synchronous heavy work during interaction;
- accidental scroll blocking;
- visual tearing;
- delayed control state;
- stuck UI.

Interaction must remain responsive during:
- opening/closing;
- scrolling;
- swiping;
- menu interaction;
- changing blur/material settings;
- changing time/date state;
- large changelog/About pages;
- feature navigation.

# 36. DIAGNOSTICS / TROUBLESHOOTING / RECOVERY

Chrona needs genuine internal diagnostics, not a fake “Recovered Mode.”

The diagnostic architecture should:
- identify the failing subsystem where possible;
- record bounded, useful diagnostic information;
- distinguish UI, state, storage, capability and integration failures;
- offer Retry when retry is meaningful;
- offer Safe UI Mode when rendering/state corruption is suspected;
- preserve user data;
- avoid pretending recovery succeeded when it did not;
- provide a useful path back to normal operation.

“Retry” and “Safe” may share recovery infrastructure but must have distinct semantics.

# 37. ABOUT / CONTINUUM / DEVELOPER OPTIONS / CHANGELOGS

These pages require actual rework, not tiny text changes.

About:
- product identity first;
- Chrona X IP/product family;
- app/build identity;
- capabilities;
- product information;
- developer information;
- similar conceptual information architecture to strong mobile app “About this app” surfaces, without cloning Samsung/Xiaomi.

Continuum:
- internal Chrona platform foundation;
- state/runtime;
- material/rendering;
- motion;
- capabilities;
- data/persistence;
- recovery/diagnostics;
- extensions/integration mechanisms.

Developer Options:
- proper grouping;
- no giant text overflowing section boundaries;
- consistent control sizes;
- useful engineering controls;
- diagnostics;
- capability inspection;
- motion/material inspection where appropriate.

Changelogs:
- cumulative historical archive must remain;
- current version first;
- user-facing changes AND internal engineering changes;
- minor and major aspects of major and minor changes;
- implementation/code references useful for future restoration/debugging;
- never silently delete historical entries.

# 38. RECORDING / VISUAL ANALYSIS STANDARD

When the Chrona recording is available, analyze it as actual continuous video, not as a collection of representative screenshots.

Inspect:
- every visible movement;
- frame-to-frame transitions;
- touch indicators;
- swipe trajectory;
- gesture timing;
- scroll behaviour;
- easing;
- overshoot/settling;
- blur/material response;
- fades/vignette;
- control state response;
- micro-interactions;
- glitches;
- redraw artefacts;
- placement shifts;
- clipping;
- layering.

The user specifically cares about extremely fine temporal behaviour. Do not reduce a video observation to “the screenshot looks wrong.”

# 39. PRODUCT QUALITY TARGET

Chrona should feel like a real mature mobile product, not a document-like web page.

Quality references include:
- Xiaomi Clock / HyperOS 2.x–4.x interaction quality;
- Android 16/17 platform behaviour;
- Material 3 Expressive principles;
- iOS 26/27-class smoothness/material quality.

These are **quality targets and reference behaviours**, not instructions to copy their visual identity.

Chrona's own identity, shape language, typography and product architecture remain authoritative.

# 40. ABSOLUTE “DO NOT DO THIS AGAIN” LIST

Never again:

1. Revert the whole product to 6.12.x because 6.12.x is the visual baseline.
2. Remove later features merely because their implementation is broken.
3. Replace the current build with an older artifact without permission.
4. Change the version number without explicit permission.
5. Add another emergency CSS/JS patch over a conflicting authority.
6. Claim a major update when only a handful of changes were made.
7. Claim runtime/device validation when only source inspection was performed.
8. Claim a fake recovery mechanism is functional.
9. Pretend permissions were requested when they were not.
10. Pretend an external path works when it has not been verified.
11. Replace live blur with a static image/cheap transparency.
12. Fix one slider while leaving the underlying settings architecture broken.
13. Treat the recording as screenshots rather than continuous interaction evidence.
14. Rebuild from scratch in a way that silently deletes accumulated product work.
15. Add duplicate mechanisms with different names that perform the same job.

# 41. REQUIRED REBUILD METHOD

For the next full Chrona rebuild:

### Phase A — inventory
Audit the latest current artifact plus historical 6.12.x and later 7.1.x artifacts.

### Phase B — feature preservation map
For every feature/mechanism, classify:
- working;
- broken;
- incomplete;
- duplicate;
- conflicting;
- obsolete;
- missing.

Do not delete anything merely because it is difficult.

### Phase C — authority map
Assign one owner to every subsystem.

### Phase D — integration
Bring the later features back into the protected 6.12.x visual/product foundation.

### Phase E — repair
Fix actual causes rather than appending overrides.

### Phase F — interaction pass
Audit touch, swipe, gesture, scroll, keyboard, pointer and accessibility behaviour.

### Phase G — material/motion pass
Audit live blur, vignette, lighting, fades, separators, easing, opening/closing and feature-specific choreography.

### Phase H — integration pass
Audit external paths, permissions, PWA capabilities, notifications, sound/ringtone and OS/browser bridges.

### Phase I — stability pass
Audit initialization, navigation, state synchronization, storage, diagnostics and recovery.

### Phase J — release validation
Only after all of the above should the build be called a major update.

# 42. DEEPSEEK HANDOFF RULE

DeepSeek must treat this document as an engineering handoff, not a loose feature wishlist.

If an instruction appears expensive or unusually detailed, that is intentional. The user has repeatedly explained that there is a reason for the requested granularity.

When uncertain, inspect the existing source/history rather than guessing.

The user's explicit version lock always wins over an inferred release-number change.


## Current engineering addendum (2026-11-21)

The active release identity is `7.1.0.10.00-release`; the archival consolidated handoff's `7.1.0.0.00-release` is a conflicting stale value and is not authoritative. See `VERSION_AUTHORITY.md`. The complete accumulated defect/feature acceptance register is `FEATURE_GAPS_AND_FIX_PLAN.md`; architecture and new ecosystem boundaries are `ARCHITECTURE_AND_STACK.md` and `IP_ECOSYSTEM_AND_NETWORK_IDENTITY.md`. Android 16/API 36, AGP, exact-alarm, notification, signing, 16 KB page-size and Redmi 13C gates are in `APK_BUILD_AND_RELEASE_GATES.md` and `DEVICE_PROFILE_AND_TEST_PLAN.md`.
