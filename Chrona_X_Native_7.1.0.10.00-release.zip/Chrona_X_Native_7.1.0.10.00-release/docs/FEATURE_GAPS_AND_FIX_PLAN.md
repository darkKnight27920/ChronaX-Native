# Chrona X: accumulated defect and missing-feature register

This register consolidates the October 8 master handoff, the recovered historical release requirements, and the current native source audit. It is the acceptance ledger, not a claim that all items are already implemented.

Status labels: **Source foundation** = architecture or partial code exists; **Unimplemented** = no meaningful implementation; **Device gate** = source exists but requires hardware/OS verification; **Preservation** = must not be removed.

## A. Product and release integrity

- Preserve `7.1.0.10.00-release` exactly. Resolve the conflicting archival `7.1.0.0.00-release` value in favour of the current source and explicit user instruction.
- Never roll the product back to 6.12.x. 6.12 is a proven visual/behaviour reference only; all legitimate post-6.12 features and later approved 7.1 work remain in scope.
- Preserve the Web/PWA as a real separate Chrona delivery. Native Android must be Flutter/Kotlin/Rust, not a WebView shell.
- Maintain one authoritative owner per feature, state, route, persistence boundary, motion system and platform capability.
- Maintain accurate public and engineering changelogs, including implementation owner, migration impact, compatibility and regression links where known.

## B. Reported UI/layout failures to prevent and repair

- Header and footer geometry must not collapse; titles must remain horizontal. Prevent individual-character vertical wrapping such as `A L A R M`.
- Prevent arrows/chevrons from appearing under text or occupying the wrong grid/flex column.
- Fix broken safe-area, bottom navigation/belt, keyboard insets, narrow-screen overflow and controls pushed below their intended row.
- Fix Home tile spacing, inconsistent radii/padding, clipped lower logo, obscured greeting/headings, double layers and cheap transparency.
- Keep responsive geometry; never hard-code 720×1600 as the layout model.
- Settings must have semantic groups, reliable scrolling, stable state during scroll/navigation and no duplicate control ownership.
- Feature-specific overflow menus must be context-aware, animated, immediately responsive and free of duplicate actions. Home and Settings follow their established exceptions. Remove only the explicitly unwanted “Add to belt” action; preserve other useful actions.
- More sheet must retain a native drag/snap/dismiss interaction, not a static modal pretending to be draggable.
- Restore the classic continuous left-to-right chevron loop where appropriate. Belt icons stay still at rest and use distinct, subtle tap responses. Logo/icon taps acknowledge immediately.
- Prevent dead touch areas, delayed navigation disguised as animation, stacked route handlers, disappearing controls, giant overlays and transition collisions.

## C. Material, motion and controls

- Live blur must be real where platform capability permits, never a screenshot, stale cache or generic translucent rectangle presented as blur.
- Blur OFF must remove the effect and disable/neutralize blur-dependent controls. Vignette OFF must disable vignette-dependent controls and stop their interaction.
- Vignette must be a real runtime effect with correct depth, clipping and motion, not a static decorative layer.
- Sliders need coherent track/thumb dimensions, rounded progress, matching progress endpoint geometry, immediate value feedback, proper drag/press and inert disabled states. No oversized or misaligned knobs and no lag.
- Use one tokenized radius/spacing/typography/color/material/motion system. Avoid late CSS-style override piles and competing visual authorities.
- Use physically plausible easing, interruptible/reversible transitions, feature-specific motion, reduced-motion support and immediate acknowledgement. No cheap bounce or animation that delays an action.
- Profile expensive blur, shader and shadow work on the Helio G85-class device; adapt quality without silently changing the visual contract.

## D. Preserved feature inventory

All are preservation requirements even when the native implementation is not yet complete:

- Digital, analog and combined clock modes.
- World Clock, saved locations, local-time conversion, IANA time zones, DST, day/night vocabulary and real local-time analog faces.
- Alarms, labels, repeat days, snooze, ringtone/audio choice, volume model and native scheduling.
- Timer, countdown and presets; stopwatch and laps.
- Tasks/reminders; Focus; Pomodoro; Intervals; Sleep/Bedtime.
- Calendar; Notifications; Time Zones; Date Calculator; Meeting Planner; Time Difference; Day Counter.
- More feature library; Quick Glance; Mini Widgets; home customization.
- Settings; About; What's New and full historical changelog archive; install surfaces.
- Continuum; Data Vault; App Health; diagnostics/recovery; Developer Options; extensions/plugins/API concepts; command/action surface.
- Chrona Studio/customization, profiles, typography, density, motion, home behaviour, appearance/material controls and data tools where historically introduced.
- Real localization/language switching and persistent user state.

No feature may be marked “implemented” merely because it appears in a registry or list. A feature needs meaningful domain logic, persistence where appropriate, real navigation and acceptance tests.

## E. Permissions and Android external paths

- Sound/audio capability UI must report actual state and use real Android integration. Ringtone selection must open the correct system picker and return a usable URI.
- Notifications must appear immediately below Sound in Settings, report real permission/channel state, request `POST_NOTIFICATIONS` on API 33+, and refresh after returning from system settings.
- Exact-alarm access must be checked with `AlarmManager.canScheduleExactAlarms()`. The app must explain the need before sending the user to Alarms & reminders settings. Never report “denied” before a real request/state check.
- All Android Settings routes/intents must handle missing handlers, cancellation and returning to the app. No fake permission result.
- Battery-optimization exemptions must not be requested indiscriminately. Do not promise OEM background guarantees that Android/HyperOS does not provide.

## F. Reliability, recovery and platform integrity

- App Health must diagnose route/state failures, missing capabilities, permission mismatch, migration/storage faults, render/material problems, timer/alarm drift, notification registration mismatch and unsupported platform APIs where observable.
- Recovery must do useful work: retry, safe action, affected-subsystem reset, diagnostic detail and copy/share report. Never wipe all Chrona data to fix a UI fault.
- Continuum must inspect real state ownership, rendering, motion, capabilities, migration, data safety, recovery, compatibility and extensions. No invented technical statistics.
- Developer Options remain gated behind the intentional seven-tap unlock. Tapping the ordinary settings row must not open it. Normal users must not see engineering-only features. Advanced changelog remains gated.
- About must communicate Chrona identity, product family, release identity, platform foundation and genuine links without cloning another app's About page.
- Persistent data needs versioned schemas, additive migrations, safe recovery and export/restore. Separate UI state, product state, timing state and Android-derived registration state.

## G. Timing and alarms

- Timer/stopwatch state must derive from persisted timestamps/monotonic semantics, not a widget ticker that resets when the UI is disposed.
- Android/Kotlin owns exact alarm scheduling, notifications/channels, ringtone/audio focus, permission checks, reboot/time/timezone/package-update reconciliation and lifecycle integration.
- Rust owns deterministic, platform-independent calculations only; it does not own Android scheduling.
- A persisted Chrona alarm is canonical. Android AlarmManager registrations are derived projections that can be rebuilt.
- Support one-shot, weekly repeat mask, labels, snooze, disable/edit/delete, next occurrence, timezone/wall-clock changes, reboot, process death and permission revocation/grant.
- Do not claim killed-process, Doze, OEM background or ringtone behaviour until device-tested.

## H. Performance, accessibility and adaptation

- Smooth scrolling, immediate controls, no jank/crashes/frozen screens/runaway effects, bounded memory and GPU-aware materials.
- Test 60/90 Hz behaviour, thermal load, battery use, low-memory conditions and background lifecycle.
- Support portrait/landscape, narrow phones, larger screens, font/display scaling, safe areas, gesture insets, semantic labels, touch target sizes and reduced motion.
- No fixed screen dimensions or unsupported OEM hacks.

## I. Acceptance rule

A fix is complete only when the owning implementation, dependencies, state/navigation, regression paths, disabled states, narrow layouts, lifecycle restoration and relevant external paths have been checked. Separate source/automated validation from emulator and physical-device validation. A visible label or source placeholder is never proof of a working feature.
