# Chrona X device profile and validation plan

## Primary target

- Device: Redmi 13C Global.
- Android: 15.
- Xiaomi software: HyperOS 2.2.
- SoC: MediaTek Helio G85.
- RAM: 6 GB.
- Display class: 720p-class, 90 Hz-capable panel; validate the actual active refresh mode rather than assuming it is always 90 Hz.
- Storage: eMMC-class; avoid excessive small-file writes and repeated database rewrites.
- No root, Magisk or PC is assumed for user-side installation/testing.

## Performance design rules

- Keep home clock updates cheap; avoid rebuilding the entire screen every second.
- Do not keep a permanent Dart timer alive when the screen is backgrounded. Derive displayed time from current timestamps on resume.
- Use bounded animations and avoid full-screen backdrop filters, multiple nested blurs, excessive shader layers and large continuously animated shadows.
- Treat live blur as an optional high-cost effect: clip to small surfaces, profile frame time, and use a truthful lower-cost material fallback when the device cannot sustain it.
- Vignette should be a single composited layer, not repeated per card.
- Keep lists lazy and images/assets local where practical. Avoid repeated synchronous disk reads on the UI isolate.
- Use isolates/Rust for CPU-heavy deterministic work only when measurement shows benefit; do not FFI-hop trivial calculations every frame.
- Avoid polling for permissions/capabilities; refresh on lifecycle/resume and explicit user action.
- Batch durable writes and use SQLite transactions; don't write a database row every visual tick.
- Respect system battery saver and reduced-motion preferences.

## Required test matrix

| Test | Expected result |
|---|---|
| Cold start, warm start | No crash, no stuck splash, correct route restoration |
| Rotate portrait/landscape | No clipped logo/title, no vertical character wrapping, controls remain reachable |
| Display/font scale 1.0–1.3+ | No collapsed rows or inaccessible controls |
| 60 Hz and 90 Hz modes | Stable frame pacing; no forced refresh-rate policy |
| Blur/vignette enabled/disabled | Real effect when enabled; dependent controls neutral and inert when disabled |
| Low-memory/background return | State restored; no duplicate timers or alarms |
| Battery saver / Doze | Exact alarms behave according to Android policy; no false guarantees |
| Exact-alarm permission denied/granted/revoked | Accurate status; no false “scheduled” state; reconciliation after grant |
| Notifications denied/allowed/channel disabled | Accurate UI state and useful recovery path |
| Ringtone URI unavailable | Safe fallback and clear user-visible status |
| Reboot/time/timezone change | Alarm registrations reconciled from canonical persisted state |
| Update over previous Chrona data | Additive migration; no data loss |
| Storage full/corrupt record | Targeted recovery; no whole-app data wipe |
| Gesture back/predictive back | Correct route stack and system animation |
| Thermal soak 15–30 min | No runaway animation, excessive heat or memory growth |

## Evidence required

Attach build SHA, APK/AAB checksum, device model/build fingerprint, Android API, permission states, test steps, logs and measured frame/memory/thermal observations. Do not report a test as passed without recorded evidence.
