# Chrona X native architecture and engineering stack

## Product version
`7.1.0.10.00-release` remains locked. See `VERSION_AUTHORITY.md`.

## Stack decisions

| Layer | Technology | Responsibility |
|---|---|---|
| Product UI | Flutter + Dart | Native-rendered screens, accessibility, adaptive layout, gestures, transitions and interaction state |
| App state | Riverpod (planned adoption) | Explicit state ownership, dependency injection and lifecycle-safe providers |
| Navigation | go_router (planned adoption) | One route owner, nested navigation and predictive-back-compatible route handling |
| Local database | SQLite via Drift (planned adoption) | Canonical persisted alarms, tasks, locations, preferences, profiles, history and migrations |
| Domain/time engine | Rust | Deterministic calculations, elapsed/remaining arithmetic, date math and testable domain algorithms |
| FFI | flutter_rust_bridge v2 preferred for typed APIs; C ABI retained only for tiny stable primitives | Typed Dart/Rust boundary; generated code must be committed or reproducibly generated |
| Android platform | Kotlin + AndroidX | AlarmManager, notifications, runtime/special permissions, ringtone/audio focus, lifecycle, reboot/time changes, settings intents |
| Deferrable work | AndroidX WorkManager | Non-exact maintenance, export preparation, cleanup and deferred tasks only. Never use it as an exact alarm clock. |
| Secrets | Android Keystore | Protect locally stored cryptographic keys/tokens; never put secrets in source or plain preferences |
| Localization | Flutter gen-l10n + ICU/intl | Centralized translation, locale persistence, plural/date/number formatting |
| Build/release | GitHub Actions + Codemagic | Repeatable lint/test/build/sign/artifact pipeline; secrets held outside repository |

Dependencies are to be introduced in coherent, tested increments. Do not add packages solely to make the architecture diagram look sophisticated.

## Ownership boundaries

1. Flutter owns presentation and user intent. Widgets do not own durable product state.
2. Drift/SQLite is the canonical local product store. SharedPreferences/DataStore may hold small non-critical preferences only.
3. Rust owns deterministic pure logic. It does not access Android APIs, schedule OS alarms, request permissions or own the database.
4. Kotlin owns Android-specific capabilities and derived registrations. It must not become a second source of truth for user-authored alarm/task records.
5. Kotlin may maintain a compact, versioned boot-recovery projection of enabled alarms. That projection is explicitly derived from the canonical database and must be replaceable/reconciled from Flutter state.
6. WorkManager handles deferrable work. AlarmManager handles user-requested exact clock alarms when the permission/policy allows.
7. One router, one feature registry, one token system, one persistence authority and one motion contract.

## Suggested module layout

```text
lib/
  app/                 app bootstrap, router, shell
  design_system/       tokens, components, motion, materials
  features/            clock, alarms, world_clock, timer, focus, tasks, calendar,
                       planner, settings, about, continuum, data_vault, health
  domain/              typed entities, use cases, repository contracts
  data/                Drift database, DAOs, migrations, repositories, backup/export
  platform/            Android MethodChannel/EventChannel adapters
  bridge/              generated Rust bridge only
  l10n/                 generated localization
rust/
  src/api/             exported deterministic APIs
  src/domain/          pure time/date/scheduling rules
  tests/               property and regression tests
android/app/src/main/kotlin/com/chronax/clock/
  alarms/              scheduler, receiver, boot/time/permission reconciliation
  notifications/       channels, actions, capability state
  audio/               ringtone selection and audio focus/ringing lifecycle
  permissions/         exact alarm, notification and settings route handling
  diagnostics/         platform capability and failure reports
```

## Additional high-impact systems

- Capability registry: typed available/granted/restricted/unsupported/unknown state, timestamped observation and reason. No decorative permission toggles.
- App Health: real diagnostics with subsystem ownership, redacted reports, copy/share and safe targeted recovery.
- Data Vault: export/import, schema version, integrity validation, backup metadata and restore preview. Never destructive import by default.
- Chrona Studio: runtime-backed appearance, density, typography, motion, home layout and profiles. Every control must change a real token/state.
- Profile engine: named user configurations with explicit merge/override rules; profiles do not fork the app's global settings authority.
- Extension registry: signed, versioned capability declarations and scoped permissions. No arbitrary untrusted native code execution.
- Chrona Sync (future): optional, encrypted, conflict-aware sync. Local-first remains usable without account/network.
- Chrona API (future): versioned contracts, authentication, rate limits, regional routing and documented deprecation policy.
- Release/compatibility registry: Android API, device capability and feature support matrix.

## UI and motion contracts

- Material 3 foundations with Chrona-owned tokens; no pixel-copy of Xiaomi/One UI.
- SafeArea/window insets and responsive constraints, never fixed 720x1600 geometry.
- Live blur only when measured platform performance permits; clip blur to small regions, avoid full-screen/backdrop stacks, degrade to a truthful translucent material when not supported.
- Vignette is runtime-controlled and subordinate to a single effect owner.
- Disabled dependent controls are visibly neutral and non-interactive.
- Press acknowledgement is immediate; route changes are not delayed for decorative motion.
- All transitions are interruptible, reversible and reduced-motion aware.
- Slider thumb, track and progress geometry are a single component contract.

## Timing invariants

- Timer: store target/started timestamps and derive remaining duration; do not count UI ticks.
- Stopwatch: use monotonic elapsed time while the process is alive and persist a wall-clock anchor plus monotonic delta policy for restoration; document reboot semantics.
- World Clock: store IANA zone IDs, never frozen offsets.
- Alarm: store local wall time, repeat-day mask, zone policy, enabled state, label, snooze/ringtone preferences. Android registrations are recalculated projections.
- Rust functions are deterministic and timezone-independent unless a timezone database is deliberately introduced and tested.

## Testing pyramid

- Rust unit/property tests for date/time invariants and overflow.
- Dart unit tests for use cases, repositories, migrations and state transitions.
- Widget/golden tests for layout, text scale, disabled controls and motion states.
- Kotlin unit/instrumentation tests for alarm recurrence, permissions, PendingIntent identity and notification channels.
- Flutter integration tests for end-to-end flows and state restoration.
- Physical Redmi 13C tests for HyperOS, Doze, reboot, killed process, audio, exact alarms, 60/90Hz, GPU, memory and thermal behaviour.
