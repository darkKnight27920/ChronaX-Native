# Chrona X security, privacy and public repository rules

- The GitHub repository `darkKnight27920/ChronaX-Native` is public and currently empty at audit time. Every pushed file and commit becomes publicly readable.
- Never push signing keys, keystores, passwords, tokens, private certificates, real user databases, alarm labels from personal backups, diagnostic logs containing personal data, or service credentials.
- Use `.gitignore` for local build outputs, `.env*`, keystores and generated machine-specific files. Add explicit allow-list review before commits.
- Use GitHub Actions secrets / Codemagic secure variables for credentials. Rotate any credential that reaches public history; deleting the latest file is insufficient.
- Keep Chrona core local-first. Do not require an account or network for clock, alarm, timer, stopwatch or saved local data.
- Any future cloud sync must be opt-in, encrypted in transit and at rest, conflict-aware and documented. Consider end-to-end encryption for user content before implementation.
- Diagnostics are local by default. Copy/share must show a preview and redact IDs, tokens, private file paths and user-entered content unless explicitly selected.
- No analytics or telemetry by default. Future collection requires explicit consent, purpose limitation, retention rules and regional policy review.
- Store cryptographic keys in Android Keystore. Do not invent custom cryptography; use reviewed platform libraries/protocols.
- Extensions must be signed, versioned and permission-scoped. Do not execute arbitrary untrusted native code or grant blanket data access.
- Public visibility does not itself grant a licence. Do not add an open-source licence or claim trademark registration without the owner's explicit decision.
