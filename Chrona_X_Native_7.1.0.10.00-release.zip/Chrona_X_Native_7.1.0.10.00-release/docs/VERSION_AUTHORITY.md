# Chrona X version authority

**Public product version: `7.1.0.10.00-release`**

This value is locked. It is the version present in the recovered 7.1.0.10.00 HTML release, the October 8 canonical handoff, and the user's explicit instruction in this project conversation. No version promotion or renaming is authorized.

## Conflicting archival metadata

A separate consolidated handoff in the Library says `7.1.0.0.00-release`. That conflicts with the current source artifact and the October 8 canonical handoff. It is recorded as a stale/conflicting archival value, not adopted as the active release identity.

## Separate identifiers

- `versionName`: `7.1.0.10.00-release` (user-facing product identity).
- Flutter package version: `7.1.0+71010000` (tooling representation; not a replacement for `versionName`).
- Android `versionCode`: `71010000` is the proposed monotonic first native package code. It must only increase for future Play releases.
- Android `applicationId`: `com.chronax.clock` is the current project candidate. Treat it as effectively permanent after first store publication; verify ownership before publishing.

The HTML/Web/PWA and native Android deliveries share the Chrona X product identity but may have independent internal build numbers and release pipelines. Do not silently alter the public product version to satisfy package-manager semantics.
