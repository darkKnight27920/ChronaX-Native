# Chrona X Android APK/AAB phase: build constraints and release gates

## Locked product/package identity

- Product `versionName`: `7.1.0.10.00-release`.
- Flutter package version: `7.1.0+71010000`.
- Proposed Android `versionCode`: `71010000`, then strictly increasing for each Play update.
- Candidate `applicationId`: `com.chronax.clock`; do not change after first publication.
- No version promotion or 8.x change without explicit user approval.

## Android API and toolchain requirements

As of 21 November 2026, Google Play requires new Android phone apps and updates to target Android 16 / API 36 or higher from 31 August 2026. Android 16 targeting requires edge-to-edge readiness and predictive-back testing. Minimum AGP for API 36 is 8.9.1. The project currently used AGP 8.7.3 and compile/target 35, so it must be upgraded before Play submission.

- `compileSdk = 36` and `targetSdk = 36` for Play-bound builds.
- Android Gradle Plugin at least `8.9.1` for API 36; use a compatible Gradle wrapper (8.11.1 minimum for AGP 8.9.x) and Java 17 unless the selected newer toolchain requires otherwise.
- Android NDK r28 or newer for 16 KB ELF alignment by default; verify all Rust/prebuilt native libraries, not only the Rust crate.
- `minSdk = 23` is the current proposal, not a promise that all devices are supported. Validate plugin and dependency minimums before locking it.
- Keep AndroidX and Flutter's supported Gradle plugin structure. Do not mix old imperative Flutter Gradle application with the modern plugin loader.

## Android platform restrictions and handling

### Exact alarms

- Use exact alarms only for user-facing clock/alarm functions that genuinely require exact delivery.
- The current plan uses `SCHEDULE_EXACT_ALARM` user-granted special access. Check `canScheduleExactAlarms()` immediately before scheduling.
- Explain the reason before opening `ACTION_REQUEST_SCHEDULE_EXACT_ALARM`; re-check on return and listen for `ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED`.
- If access is absent, do not pretend scheduling succeeded. Show a truthful degraded state and let the user choose the system settings route.
- `USE_EXACT_ALARM` is a possible alternative for a qualifying alarm-clock app but is policy-restricted on Google Play. Do not switch to it without a policy eligibility review.
- Prefer `AlarmManager.setAlarmClock()` for user-visible wake-up alarm-clock semantics where appropriate. Exact alarms have battery cost; do not use them for routine background refresh.

### Notifications and sound

- Declare `POST_NOTIFICATIONS` and request it at a contextual moment on Android 13/API 33+.
- Report runtime permission separately from notification-channel state and app-level notification enablement.
- Create stable notification channel IDs. Android users control channel sound/importance after creation; changing channel settings in app code cannot override user choices.
- Ringtone picker and playback/audio-focus are separate from notification permission. Store selected ringtone URI safely and handle missing/revoked URI access.
- Do not claim audible alarm delivery, full-screen alarm presentation or audio-focus behaviour until tested on target hardware and current Android policy.

### Background and OEM policy

- AlarmManager for exact user alarms; WorkManager for deferrable maintenance only.
- Do not run a permanent foreground service just to keep a clock UI alive.
- Do not request battery-optimization exemptions for convenience. Request only where a concrete, permitted user-facing feature requires it and explain consequences.
- Xiaomi/HyperOS may impose additional autostart/background controls. Document supported user guidance only after testing the exact device/ROM. Never claim Android can guarantee an OEM setting.
- Reconcile alarms after boot, package replacement, time set/timezone change and exact-alarm access grant. Permission revocation cancels scheduled exact alarms; app state must reveal this.

### Android 16 UI and native binary requirements

- Edge-to-edge is mandatory for API 36-targeting apps on Android 16. Test status/navigation bars, keyboard, gesture insets and display cutouts.
- Predictive back is enabled by default. Use supported navigation/back APIs and test cross-task/back-to-home gestures.
- Test large-screen/resizable behaviour even though the first target is a phone.
- Native Rust libraries must be 16 KB page-size compatible. NDK r28+ defaults to 16 KB ELF alignment; inspect every `.so` and APK/AAB alignment with Android tooling.
- Test 4 KB and 16 KB page-size environments where possible.

## Signing and public repository security

- Never commit `.jks`, `.keystore`, key passwords, API secrets, production endpoints with embedded credentials or personal data.
- Store keystore and credentials in Codemagic secure file/variable groups or GitHub Actions secrets.
- Keep two secure offline backups of the owner-controlled signing material.
- For Play, use Play App Signing and preserve upload-key custody. For direct APK distribution, future updates must be signed with the same app signing identity.
- Public repository contents and history are public. Removing a secret later does not erase it from Git history; rotate any leaked credential immediately.

## Build pipeline stages

1. Source lint: Dart format/analyze, Rust fmt/clippy/test, Kotlin lint/test.
2. Dependency and licence inventory; pin compatible tool versions and retain lockfiles.
3. Generate/verify Rust FFI bindings; build `arm64-v8a` first, then add `armeabi-v7a`/`x86_64` only where supported and needed.
4. Build debug APK for internal installation tests.
5. Build signed release APK/AAB only when owner signing material is configured.
6. Verify APK/AAB signature, package ID, versionName/versionCode, ABI contents, native library page alignment and manifest permissions.
7. Install/update over the previous Chrona build and test data migration, not just clean install.
8. Run physical Redmi 13C validation, then wider Android compatibility testing.

## Mandatory release gates (not yet passed)

- Flutter analyzer/tests and integration tests.
- Rust unit/property tests and Android cross-compilation.
- Kotlin compilation and instrumentation tests.
- Gradle build with API 36 and current supported AGP.
- Signed APK/AAB, install, update and uninstall behaviour.
- Exact alarm request/grant/deny/revoke, reboot, process death, Doze, timezone and wall-clock changes.
- Notification permission/channel state, ringtone picker, audio focus, volume and dismissal/snooze.
- HyperOS autostart/background behaviour on the actual Redmi 13C.
- 60/90 Hz smoothness, GPU/raster frame time, memory, battery and thermal tests.
- Accessibility, font scaling, landscape, safe areas, keyboard and predictive back.
- Data migration/export/import/restore and corrupted-data recovery.

No release-ready claim until these gates have evidence attached to the build.
