import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'src/rust/api.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(ChronaApp(prefs: prefs));
}

class ChronaApp extends StatelessWidget {
  const ChronaApp({super.key, required this.prefs});
  final SharedPreferences prefs;
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Chrona X',
    debugShowCheckedModeBanner: false,
    theme: ThemeData.dark(useMaterial3: true),
    home: ChronaHome(prefs: prefs),
  );
}

class ChronaHome extends StatefulWidget {
  const ChronaHome({super.key, required this.prefs});
  final SharedPreferences prefs;
  @override State<ChronaHome> createState()=>_ChronaHomeState();
}
class _ChronaHomeState extends State<ChronaHome> {
  String route='home';
  final routes=['home','alarms','world','timer','stopwatch','tasks','focus','pomodoro','intervals','lap','sleep','calendar','timezone','datecalc','difference','daycounter','meeting','more','settings','about','whatsnew','developer','install'];
  @override Widget build(BuildContext context)=>Scaffold(
    appBar: AppBar(title: const Text('Chrona X'), actions:[if(route!='home'&&route!='settings') PopupMenuButton<String>(onSelected:(v)=>setState(()=>route=v),itemBuilder:(c)=>const [PopupMenuItem(value:'settings',child:Text('Settings')),PopupMenuItem(value:'about',child:Text('About')),PopupMenuItem(value:'whatsnew',child:Text("What's new"))])]),
    body: AnimatedSwitcher(duration: const Duration(milliseconds:260), child: Center(key:ValueKey(route),child:Text(route,style:Theme.of(context).textTheme.displaySmall))),
    bottomNavigationBar: NavigationBar(selectedIndex: ['home','alarms','timer','focus','more'].indexOf(route).clamp(0,4),onDestinationSelected:(i)=>setState(()=>route=['home','alarms','timer','focus','more'][i]),destinations:const [NavigationDestination(icon:Icon(Icons.access_time),label:'Home'),NavigationDestination(icon:Icon(Icons.alarm),label:'Alarms'),NavigationDestination(icon:Icon(Icons.timer),label:'Timer'),NavigationDestination(icon:Icon(Icons.center_focus_strong),label:'Focus'),NavigationDestination(icon:Icon(Icons.more_horiz),label:'More')]),
  );
}
