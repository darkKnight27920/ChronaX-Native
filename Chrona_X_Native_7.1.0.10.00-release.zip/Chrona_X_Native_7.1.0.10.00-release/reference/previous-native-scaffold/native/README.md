# Chrona X Native — Continuum Reforge

This is the independent native foundation requested for the 7.x language/architecture switch.

- Flutter/Dart owns UI, navigation, adaptive layout, motion and platform-facing presentation.
- Rust owns deterministic time/data/algorithm primitives and can grow into alarms, date math, scheduling and other core services.
- `flutter_rust_bridge` is the boundary between Dart and Rust.
- The native project is deliberately written from scratch; it does not import the previous HTML/React/Vue runtime.
- The included root `index.html` is the separate installable web/PWA companion, not the native runtime.

Build with Flutter + Rust on a development machine. This environment does not contain the Flutter SDK, so no APK/AAB/IPA binary is falsely claimed here.
