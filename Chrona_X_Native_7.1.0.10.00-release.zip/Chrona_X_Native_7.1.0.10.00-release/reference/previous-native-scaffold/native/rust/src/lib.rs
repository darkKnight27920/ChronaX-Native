use chrono::{Local, Timelike};

pub fn local_time_hm() -> String {
    let now = Local::now();
    format!("{:02}:{:02}", now.hour(), now.minute())
}

pub fn seconds_between(a: i64, b: i64) -> i64 { b.saturating_sub(a) }
