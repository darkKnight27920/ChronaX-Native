//! Chrona X deterministic domain primitives.
//! Android scheduling, permissions, audio and lifecycle remain Kotlin-owned.

/// Non-negative elapsed duration with saturating subtraction.
#[no_mangle]
pub extern "C" fn cx_elapsed_ms(start_ms: i64, now_ms: i64) -> i64 {
    now_ms.saturating_sub(start_ms).max(0)
}

/// Non-negative remaining duration until a wall-clock target.
#[no_mangle]
pub extern "C" fn cx_remaining_ms(target_ms: i64, now_ms: i64) -> i64 {
    target_ms.saturating_sub(now_ms).max(0)
}

/// Signed difference `end - start`, saturating rather than overflowing.
#[no_mangle]
pub extern "C" fn cx_signed_difference_ms(start_ms: i64, end_ms: i64) -> i64 {
    end_ms.saturating_sub(start_ms)
}

/// Clamp a duration to a valid non-negative range.
#[no_mangle]
pub extern "C" fn cx_clamp_duration_ms(value_ms: i64, minimum_ms: i64, maximum_ms: i64) -> i64 {
    let min = minimum_ms.max(0);
    let max = maximum_ms.max(min);
    value_ms.clamp(min, max)
}

/// Gregorian civil-date day number using the proleptic Gregorian calendar.
/// Inputs are year, month (1..12), day (1..31); returns i64::MIN for invalid dates.
#[no_mangle]
pub extern "C" fn cx_civil_day_number(year: i32, month: u32, day: u32) -> i64 {
    if !(1..=12).contains(&month) || day == 0 || day > days_in_month(year, month) {
        return i64::MIN;
    }
    let y = year as i64 - if month <= 2 { 1 } else { 0 };
    let era = if y >= 0 { y } else { y - 399 } / 400;
    let yoe = y - era * 400;
    let m = month as i64;
    let mp = m + if m > 2 { -3 } else { 9 };
    let doy = (153 * mp + 2) / 5 + day as i64 - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146097 + doe
}

fn days_in_month(year: i32, month: u32) -> u32 {
    match month {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 if is_leap_year(year) => 29,
        2 => 28,
        _ => 0,
    }
}

fn is_leap_year(year: i32) -> bool {
    year % 4 == 0 && (year % 100 != 0 || year % 400 == 0)
}

/// Absolute calendar-day distance. Returns i64::MIN when either date is invalid.
#[no_mangle]
pub extern "C" fn cx_date_distance_days(
    start_year: i32, start_month: u32, start_day: u32,
    end_year: i32, end_month: u32, end_day: u32,
) -> i64 {
    let a = cx_civil_day_number(start_year, start_month, start_day);
    let b = cx_civil_day_number(end_year, end_month, end_day);
    if a == i64::MIN || b == i64::MIN { return i64::MIN; }
    (b - a).abs()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test] fn elapsed_never_negative() { assert_eq!(cx_elapsed_ms(20, 10), 0); }
    #[test] fn remaining_counts_down() { assert_eq!(cx_remaining_ms(100, 40), 60); }
    #[test] fn saturates() { assert_eq!(cx_elapsed_ms(i64::MIN, i64::MAX), i64::MAX); }
    #[test] fn signed_difference_preserves_direction() {
        assert_eq!(cx_signed_difference_ms(100, 40), -60);
        assert_eq!(cx_signed_difference_ms(40, 100), 60);
    }
    #[test] fn clamp_is_non_negative_and_bounded() {
        assert_eq!(cx_clamp_duration_ms(-2, 0, 100), 0);
        assert_eq!(cx_clamp_duration_ms(150, 0, 100), 100);
        assert_eq!(cx_clamp_duration_ms(50, 0, 100), 50);
    }
    #[test] fn leap_year_and_date_validation() {
        assert!(cx_civil_day_number(2000, 2, 29) >= 0);
        assert_eq!(cx_civil_day_number(1900, 2, 29), i64::MIN);
        assert_eq!(cx_civil_day_number(2026, 13, 1), i64::MIN);
    }
    #[test] fn date_distance_crosses_leap_day() {
        assert_eq!(cx_date_distance_days(2024, 2, 28, 2024, 3, 1), 2);
        assert_eq!(cx_date_distance_days(2026, 3, 2, 2026, 3, 1), 1);
        assert_eq!(cx_date_distance_days(1900, 2, 29, 2026, 3, 1), i64::MIN);
        assert_eq!(cx_date_distance_days(1800, 1, 1, 1900, 1, 1), 36524);
    }
}
