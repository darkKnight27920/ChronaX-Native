import 'package:flutter_test/flutter_test.dart';
import 'package:chrona_x/core/chrona_alarm.dart';
import 'package:chrona_x/core/chrona_capabilities.dart';

void main() {
  test('alarm weekday mask uses Sunday as bit zero', () {
    const alarm = ChronaAlarm(
      id: 'wake', title: 'Wake up', hour: 7, minute: 30,
      repeatMask: 0b0100001, timeZoneId: 'Asia/Karachi', enabled: true,
    );
    expect(alarm.repeatsOn(0), isTrue);
    expect(alarm.repeatsOn(5), isTrue);
    expect(alarm.repeatsOn(1), isFalse);
    expect(alarm.isValid, isTrue);
  });

  test('invalid alarm values are rejected by the domain model', () {
    const alarm = ChronaAlarm(
      id: '', title: 'Invalid', hour: 24, minute: 99,
      repeatMask: 128, timeZoneId: '', enabled: true,
    );
    expect(alarm.isValid, isFalse);
  });

  test('unsupported capability is not represented as denied', () {
    final snapshot = CapabilitySnapshot.fromAndroid(
      id: 'exactAlarm', supported: false, granted: false,
      observedAt: DateTime.utc(2026),
    );
    expect(snapshot.state, CapabilityState.unsupported);
  });
}
