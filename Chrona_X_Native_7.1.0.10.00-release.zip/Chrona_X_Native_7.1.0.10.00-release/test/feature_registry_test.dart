import 'package:flutter_test/flutter_test.dart';
import 'package:chrona_x/core/feature_registry.dart';
import 'package:chrona_x/core/release_identity.dart';
void main(){test('release identity locked',(){expect(ReleaseIdentity.versionName,'7.1.0.10.00-release');});test('preserved feature inventory present',(){final ids=chronaFeatures.map((f)=>f.id).toSet();for(final id in ['clock','alarms','world','timer','stopwatch','tasks','focus','pomodoro','intervals','sleep','calendar','notifications','timezone','datecalc','meeting','difference','daycounter','continuum','datavault','health','quickglance','widgets','developer','extensions','command']){expect(ids,contains(id));}});test('feature IDs unique',(){final ids=chronaFeatures.map((f)=>f.id).toList();expect(ids.toSet().length,ids.length);});}
